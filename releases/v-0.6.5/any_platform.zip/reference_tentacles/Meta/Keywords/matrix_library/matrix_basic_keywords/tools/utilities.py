import time


def start_measure_time(message=None):
    if message:
        print(message + " started")
    return time.time()


def end_measure_time(m_time, message, min_duration=None):
    duration = round(time.time() - m_time, 2)
    if not min_duration or min_duration < duration:
        print(f"{message} done {duration}s")


def end_measure_live_time(ctx, m_time, message, min_duration=None):
    duration = round(time.time() - m_time, 2)
    if not min_duration or min_duration < duration:
        ctx.logger.info(f"{message} done {duration}s")


class NanoContext:
    def __init__(self, exchange_manager, symbol):
        self.exchange_manager = exchange_manager
        self.symbol = symbol
        self.trader = exchange_manager.trader

    def is_trading_signal_emitter(self):
        return False


def get_nano_context(exchange_manager, symbol):
    exchange_manager.nano_ctx = (
        exchange_manager.nano_ctx
        if hasattr(exchange_manager, "nano_ctx")
        else NanoContext(exchange_manager=exchange_manager, symbol=symbol)
    )
    return exchange_manager.nano_ctx


def get_pre_order_data(exchange_manager, symbol):
    fees_currency_side = None
    if exchange_manager.is_future:
        fees_currency_side = exchange_manager.exchange.get_pair_future_contract(
            symbol
        ).get_fees_currency_side()
    symbol_market = exchange_manager.exchange.get_market_status(
        symbol, with_fixer=False
    )
    return fees_currency_side, symbol_market
