TimeFrameStrategyEvaluator is forwarding evaluator values to the trading mode.
