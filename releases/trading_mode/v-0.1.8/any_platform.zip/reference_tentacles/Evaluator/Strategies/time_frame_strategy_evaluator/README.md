# time\_frame\_strategy\_evaluator

