# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import octobot_trading.api.symbol_data as symbol_data
import octobot_commons.enums as common_enums
import octobot_trading.modes.script_keywords.basic_keywords.user_inputs as user_inputs
import tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.mode.trading_mode as basic_trading_mode
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro as managed_order_pro
import tentacles.Meta.Keywords.scripting_library.UI.inputs.select_time_frame as select_time_frame
import tentacles.Meta.Keywords.scripting_library.UI.inputs.select_history as select_history
import tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.enums as maker_enums


class SemiAutoTradeCommands:
    EXECUTE = "execute"


class SemiAutoTradingModeMaking(basic_trading_mode.MatrixMode):
    strategy_mode: str = maker_enums.StrategyModes.SEMI_AUTOMATED_TRADING
    should_execute_semi_auto: bool = False
    pairs_to_execute: list = None
    all_pairs: list = None
    enable_settings_for_all: bool = None
    action: str = None
    managend_orders_settings: dict = {}
    trading_sides: dict = {}
    trading_side_for_all: str = None
    managend_orders_settings_for_all = None

    async def make_strategy(self, ctx, action):
        self.action = action
        self.ctx = ctx
        await self.make_semi_auto_strategy()

    async def make_semi_auto_strategy(self):
        await self.initialize_base_settings()
        if self.enable_settings_for_all:
            all_pairs_settings_name: str = "all_pairs_settings"
            await user_inputs.user_input(
                self.ctx,
                all_pairs_settings_name,
                common_enums.UserInputTypes.OBJECT,
                title="Order settings for all pairs",
                def_val=None,
                show_in_summary=True,
                show_in_optimizer=False,
            )
            self.trading_side_for_all: str = await user_inputs.user_input(
                self.ctx,
                "trading_side",
                common_enums.UserInputTypes.OPTIONS,
                title="Trading side",
                def_val="long",
                options=["long", "short"],
                show_in_summary=True,
                show_in_optimizer=False,
                parent_input_name=all_pairs_settings_name,
            )
            self.managend_orders_settings_for_all = (
                await managed_order_pro.activate_managed_orders(
                    self.ctx, parent_input_name=all_pairs_settings_name
                )
            )

        for pair in self.pairs_to_execute:
            await self.initialize_pair_settings(pair)
            if (
                self.action == SemiAutoTradeCommands.EXECUTE
                and self.strategy_mode
                == maker_enums.StrategyModes.SEMI_AUTOMATED_TRADING
                and pair in self.managend_orders_settings
                and self.ctx.symbol == pair
                and self.ctx.time_frame in self.trigger_time_frames
            ):
                self.ctx.enable_trading = True

                await managed_order_pro.managed_order(
                    self.ctx,
                    trading_side=self.trading_sides[pair],
                    orders_settings=self.managend_orders_settings[pair],
                )

                # await order_types.limit(
                #     self.ctx,
                #     side="buy",
                #     amount=0.05,
                #     offset="@17000",
                #     stop_loss_offset=18000,
                # )

    async def initialize_pair_settings(self, pair):
        pair_settings_name: str = f"{pair} settings"
        await user_inputs.user_input(
            self.ctx,
            pair_settings_name,
            common_enums.UserInputTypes.OBJECT,
            title=f"{pair} settings",
            def_val=None,
            show_in_summary=True,
            show_in_optimizer=False,
            other_schema_values={
                "grid_columns": 12,
            },
        )
        if await user_inputs.user_input(
            self.ctx,
            f"{pair}_custom_settings_enabled",
            common_enums.UserInputTypes.BOOLEAN,
            title=f"Enable custom {pair} order settings",
            def_val=False,
            show_in_summary=True,
            show_in_optimizer=False,
            parent_input_name=pair_settings_name,
        ):
            self.trading_sides[pair] = await user_inputs.user_input(
                self.ctx,
                f"{pair}_custom_trading_side",
                common_enums.UserInputTypes.OPTIONS,
                title=f"Trading side for {pair}",
                def_val="long",
                options=["long", "short"],
                show_in_summary=True,
                show_in_optimizer=False,
                parent_input_name=pair_settings_name,
            )
            self.managend_orders_settings[
                pair
            ] = await managed_order_pro.activate_managed_orders(
                self.ctx, parent_input_name=pair_settings_name
            )
        elif self.enable_settings_for_all:
            self.managend_orders_settings[pair] = self.managend_orders_settings_for_all
            self.trading_sides[pair] = self.trading_side_for_all

    async def initialize_base_settings(self):
        self.cancel_non_trigger_time_frames()
        await self.set_position_mode_to_one_way()
        self.ctx.enable_trading = False
        self.all_pairs = symbol_data.get_config_symbols(
            self.ctx.exchange_manager.config, True
        )
        self.trigger_time_frames = await select_time_frame.set_trigger_time_frames(
            self.ctx
        )
        await select_history.set_candles_history_size(self.ctx, 200)
        self.pairs_to_execute = await user_inputs.user_input(
            self.ctx,
            "pairs_to_trade",
            common_enums.UserInputTypes.MULTIPLE_OPTIONS,
            title="Pairs to execute trades on",
            def_val=self.all_pairs,
            options=self.all_pairs,
            show_in_summary=True,
            show_in_optimizer=False,
        )
        self.enable_settings_for_all: bool = await user_inputs.user_input(
            self.ctx,
            "enable_settings_for_all",
            common_enums.UserInputTypes.BOOLEAN,
            title="Enable order settings for all pairs",
            def_val=False,
            show_in_summary=False,
            show_in_optimizer=False,
        )
