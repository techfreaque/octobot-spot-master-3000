# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

from tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.data.public_exchange_data import (
    get_candles_,
)


async def activate_sl_indicator(maker, path, is_trailing_stop=False):
    from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.evaluators.evaluators_handling import (
        Evaluator_,
    )

    sl_evaluator = Evaluator_(maker, input_path_root=path)
    sl_values = await sl_evaluator.init_as_sl_source_and_get_data(
        maker, is_trailing_stop=is_trailing_stop
    )
    times = await get_candles_(maker, "time")
    indicator_dict = {}
    for index in range(0, len(sl_values)):
        indicator_dict[times[-index - 1]] = sl_values[-index - 1]

    maker.managed_order_indicator_cache[
        get_cache_path(maker, is_trailing_stop, path)
    ] = indicator_dict


async def activate_trailing_sl_indicator(maker, path):
    await activate_sl_indicator(maker, path, is_trailing_stop=True)


def get_sl_indicator(ctx, maker, path, is_trailing_stop=False):
    try:
        return maker.managed_order_indicator_cache[
            get_cache_path(maker, is_trailing_stop, path)
        ][ctx.trigger_cache_timestamp]
    except KeyError:
        ctx.logger.error(
            f"SL{'trailing' if is_trailing_stop else ''} indicator doesnt have a value for the "
            f"current candle. Check the candle history size"
        )
        return False


def get_trailing_sl_indicator(ctx, maker, path):
    return get_sl_indicator(ctx, maker, path, is_trailing_stop=True)


def get_cache_path(maker, is_trailing_stop, path):
    return (
        ("b-" if maker.is_backtesting else "l-")
        + ("trail-" if is_trailing_stop else "")
        + path
    )
