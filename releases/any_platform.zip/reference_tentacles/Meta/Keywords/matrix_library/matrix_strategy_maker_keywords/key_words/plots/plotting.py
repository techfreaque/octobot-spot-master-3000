# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import octobot_commons.enums as commons_enums
import octobot_commons.constants as commons_constants


async def plot(
    ctx,
    title,
    kind="scattergl",
    mode="lines",
    line_shape="linear",
    text=None,
    chart=commons_enums.PlotCharts.SUB_CHART.value,
    cache_value=None,
    own_yaxis=False,
    color=None,
    size=None,
    shape=None,
    shift_to_open_candle_time=True,
):
    count_query = {"time_frame": ctx.time_frame}
    cache_full_path = None
    if cache_value is not None:
        # register cache path (avoid re-computing it on ctx.get_cache_path call)
        ctx.get_cache()
        cache_full_path = ctx.get_cache_path(ctx.tentacle)
        count_query["title"] = title
        count_query["value"] = cache_full_path

    if not await ctx.symbol_writer.contains_row(
        commons_enums.DBTables.CACHE_SOURCE.value, count_query
    ):
        table = commons_enums.DBTables.CACHE_SOURCE.value
        cache_data = {
            "title": title,
            "text": text,
            "time_frame": ctx.time_frame,
            "value": cache_full_path,
            "cache_value": cache_value,
            "kind": kind,
            "mode": mode,
            "line_shape": line_shape,
            "chart": chart,
            "own_yaxis": own_yaxis,
            "color": color,
            "size": size,
            "shape": shape,
            "x_shift": -commons_enums.TimeFramesMinutes[
                commons_enums.TimeFrames(ctx.time_frame)
            ]
            * commons_constants.MINUTE_TO_SECONDS
            if shift_to_open_candle_time
            else 0,
        }
        update_query = await ctx.symbol_writer.search()
        update_query = (
            (update_query.kind == kind)
            & (update_query.mode == mode)
            & (update_query.time_frame == ctx.time_frame)
            & (update_query.title == title)
        )
        await ctx.symbol_writer.upsert(table, cache_data, update_query)
