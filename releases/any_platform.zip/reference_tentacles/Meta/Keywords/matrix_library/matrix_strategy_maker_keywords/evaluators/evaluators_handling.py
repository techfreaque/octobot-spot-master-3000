# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords import (
    evaluators as evaluators,
)  # needed for evaluators
from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.indicators.indicator_handling import (
    activate_configurable_indicator,
    get_configurable_indicator,
)
from octobot_trading.modes.script_keywords.basic_keywords import user_inputs


class Evaluator_:
    # input_path_short_root = f"s{strategy_id + 1}"
    def __init__(
        self,
        maker,
        input_name_root,
        input_path_short_root="",
        supported_evaluators=None,
    ):
        if supported_evaluators is None:
            supported_evaluators = []
        self.evaluator_id = 0
        self.name = ""
        self.class_name = ""
        self.enabled = True
        self.supported_evaluators = supported_evaluators
        self.plot = False
        self.candle_source = "none"
        self.indicators = {}

        self.input_parent_name_root = input_name_root
        self.input_path_short_root = input_path_short_root
        self.base_config_path_short: str = None

        self.config_name = "none"
        self.config_path = ""
        self.cache_path = ""
        self.config_path_short = ""
        self.value_key = "v"
        self.values = []
        self.second_values = []
        self.signals = []
        self.data = {}

    async def evaluate_and_get_data(self, maker, ctx):
        if self.enabled:
            try:
                self.data = await eval(f"evaluators.get_{self.class_name}(maker, self)")
            except Exception as error:
                evaluator_error_message(self, ctx, maker, error)
                return []

            if not self.data[self.value_key] and self.data[self.value_key] != 0:
                evaluator_error_message(self, ctx, maker)
                return []
            return self.data[self.value_key]

    async def init_as_sl_source_and_get_data(self, maker, is_trailing_stop=False):
        data_source_name, indicator_id = self.init_sl_paths(is_trailing_stop)
        _ = await activate_configurable_indicator(
            maker,
            self,
            data_source_name=data_source_name,
            enable_static_value=False,
            enable_oscillators=False,
            indicator_id=indicator_id,
        )

        indicator_values, _, _ = await get_configurable_indicator(
            maker, self, indicator_id=indicator_id
        )
        return indicator_values

    def init_paths(self, maker):
        self.config_path = f"{self.input_parent_name_root}/Evaluator {self.evaluator_id + 1} - {self.name}"
        self.cache_path = f"Strategy {maker.current_strategy_id + 1}/Evaluator {self.evaluator_id + 1} - {self.name}"
        self.config_path_short = (
            f"{self.input_path_short_root}-e{self.evaluator_id + 1}"
        )
        self.base_config_path_short = self.config_path_short + "base"

    def init_sl_paths(self, is_trailing_stop):
        self.class_name = self.name = "SLSource"
        self.cache_path = self.input_parent_name_root
        self.config_path = (
            self.input_parent_name_root + "/Exit Settings/Stop Loss Settings"
        )
        if is_trailing_stop:
            data_source_name = "Trailing SL Indicator"
            indicator_id = 2
            self.evaluator_id = 201
            self.config_path_short = "mo-t"
            self.config_path += "/Trailing Stop Settings"
        else:
            data_source_name = "SL Indicator"
            indicator_id = 1
            self.evaluator_id = 202
            self.config_path_short = "mo"
        return data_source_name, indicator_id

    async def init_evaluator(self, maker, ctx, evaluator_id):
        self.evaluator_id = evaluator_id
        self.init_paths(maker)

        await user_inputs.user_input(
            ctx,
            self.base_config_path_short,
            "object",
            def_val=None,
            title=f"Evaluator {evaluator_id + 1}",
            parent_input_name=self.input_path_short_root,
            other_schema_values={
                "options": {"collapsed": True},
                "grid_columns": 12,
            },
        )
        self.enabled = await user_inputs.user_input(
            ctx,
            f"{self.input_path_short_root}_enable_evaluator_{self.evaluator_id + 1}",
            "boolean",
            def_val=True,
            title=f"enable evaluator {self.evaluator_id + 1}",
            parent_input_name=self.base_config_path_short,
        )
        if self.enabled:
            self.class_name = self.name = await user_inputs.user_input(
                ctx,
                f"{self.input_path_short_root}_select_evaluator_{self.evaluator_id + 1}",
                "options",
                def_val="is_rising",
                title=f"select evaluator {self.evaluator_id + 1}",
                options=self.supported_evaluators,
                parent_input_name=self.base_config_path_short,
            )
            await user_inputs.user_input(
                ctx,
                self.config_path_short,
                "object",
                def_val=None,
                title=f"Evaluator {evaluator_id + 1}",
                parent_input_name=self.base_config_path_short,
                other_schema_values={
                    "grid_columns": 12,
                },
            )


def evaluator_error_message(evaluator, ctx, maker, error=None):
    message = (
        f"Strategy Maker: Evaluator has no data {evaluator.evaluator_id + 1} {evaluator.name} "
        f"{evaluator.class_name}: there is probably an issue in your config. Check the settings."
    )
    if error:
        message += "Error: " + str(error)
    if error and maker.debug_mode:
        ctx.logger.exception(error, True, message)
    else:
        ctx.logger.error(message)
