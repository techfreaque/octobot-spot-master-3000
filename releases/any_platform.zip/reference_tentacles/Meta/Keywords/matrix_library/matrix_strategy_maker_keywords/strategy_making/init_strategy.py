# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import octobot_commons.errors as commons_errors
import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import octobot_trading.modes.script_keywords.context_management as context_management
from tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.enums import (
    CURRENT_TIME_FRAME,
    BacktestPlottingModes,
    LivePlottingModes,
)
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.managed_orders as managed_orders
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings as sl_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.stop_losses.stop_loss_handling as stop_loss_handling
import tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.evaluators.evaluators_handling as evaluators_handling
import tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.tools.utilities as utilities
import tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.key_words.orders.sl_sources as sl_sources


class StrategyData:
    enable_plot: bool = None
    live_recording_mode: bool = None

    def __init__(self, maker):
        self.supported_evaluators = maker.supported_evaluators
        self.signals = {}
        self.strategy_id = maker.current_strategy_id
        self.input_path = f"evaluator/Strategy_{maker.current_strategy_id + 1}_Settings"
        self.input_name = f"strategy_{maker.current_strategy_id + 1}_settings"
        # self.input_path = maker.input_path + f"/Strategy {current_strategy_id+1} Settings"
        self.config_path_short = f"s{self.strategy_id + 1}"
        self.trading_side = ""
        self.trading_side_key = ""
        self.nr_of_indicators = 0
        self.evaluators = {}
        self.managed_order_root_name = f"S{self.strategy_id + 1}_Order_Settings"
        self.managed_order_root_path = (
            f"evaluator/S{self.strategy_id + 1}_Order_Settings"
        )
        self.order_settings = None
        self.enable_strategy: bool = False

    async def build_and_trade_strategy_live(self, maker, ctx):
        await self.init_strategy(maker)
        if not self.enable_strategy:
            return
        signal = 1
        for evaluator_id in range(0, self.nr_of_indicators):
            await self.get_evaluator(maker, ctx, evaluator_id)
            if self.evaluators and evaluator_id in self.evaluators:
                signal = self.signals[evaluator_id] if signal == 1 else 0
        await self.set_managed_order_settings(ctx, maker)
        if signal == 1:
            await self.execute_managed_order(ctx, maker)
        await self.handle_trailing_stop(ctx, maker)

    async def build_strategy_backtesting_cache(self, maker, ctx):
        m_time = utilities.start_measure_time()
        await self.init_strategy(maker)
        if not self.enable_strategy:
            return
        for evaluator_id in range(0, self.nr_of_indicators):
            await self.get_evaluator(maker, ctx, evaluator_id)

        await self.set_managed_order_settings(ctx, maker)
        utilities.end_measure_time(
            m_time,
            f" strategy maker - calculating evaluators for strategy {self.strategy_id}",
            min_duration=9,
        )

    async def trade_strategy_backtesting(self, ctx, maker):
        await self.execute_managed_order(ctx, maker)

    async def init_strategy(self, maker):
        await basic_keywords.user_input(
            maker.ctx,
            self.config_path_short,
            input_type="object",
            title=f"Strategy_{maker.current_strategy_id + 1}_Settings",
            def_val=None,
            path=self.input_path,
            other_schema_values={"grid_columns": 12, "display_as_tab": True},
        )
        self.enable_strategy = await basic_keywords.user_input(
            maker.ctx,
            f"Enable Strategy ({self.config_path_short})",
            input_type="boolean",
            def_val=True,
            parent_input_name=self.config_path_short,
        )
        if not self.enable_strategy:
            return

        self.nr_of_indicators = await basic_keywords.user_input(
            maker.ctx,
            f"Amount of Evaluators combined together ({self.config_path_short})",
            "int",
            def_val=2,
            min_val=1,
            parent_input_name=self.config_path_short,
        )
        self.trading_side = await basic_keywords.user_input(
            maker.ctx,
            f"Trading direction (s{self.strategy_id + 1})",
            "options",
            def_val="long",
            options=["long", "short"],
            parent_input_name=self.config_path_short,
        )
        self.enable_plot = maker.enable_plot
        self.live_recording_mode = maker.live_recording_mode
        if (
            maker.ctx.exchange_manager.is_backtesting
            and maker.backtest_plotting_mode == BacktestPlottingModes.ENABLE_PLOTTING
        ) or (
            maker.backtest_plotting_mode == BacktestPlottingModes.ENABLE_PLOTTING
            or maker.live_plotting_mode
            in (
                LivePlottingModes.PLOT_RECORDING_MODE,
                LivePlottingModes.REPLOT_VISIBLE_HISTORY,
            )
        ):
            self.enable_plot = await basic_keywords.user_input(
                maker.ctx,
                f"enable_plots_strategy_{self.strategy_id + 1}",
                "boolean",
                title="Enable plots for this strategy",
                def_val=True,
                parent_input_name=self.config_path_short,
            )
            if not self.enable_plot:
                self.live_recording_mode = True
        self.trading_side_key = "l" if self.trading_side == "long" else "s"
        # self.input_path = f"{self.input_path}/Strategy"

    async def get_evaluator(
        self, maker, ctx: context_management.Context, evaluator_id: int
    ):
        sm_time = utilities.start_measure_time()
        evaluator = evaluators_handling.Evaluator_(
            maker, self.input_name, self.config_path_short, self.supported_evaluators
        )
        maker.current_evaluator_id = evaluator_id
        await evaluator.init_evaluator(maker, ctx, evaluator_id)
        if evaluator.enabled:
            self.evaluators[evaluator_id] = evaluator
            self.signals[evaluator_id] = await evaluator.evaluate_and_get_data(
                maker, ctx
            )
            maker.evaluators[evaluator.config_path] = evaluator
            utilities.end_measure_time(
                sm_time,
                f" strategy maker - calculating evaluator {evaluator_id + 1} "
                f"{evaluator.name} {evaluator.class_name}",
                min_duration=9,
            )

    async def execute_managed_order(self, ctx, maker):
        indicator_value = None
        if (
            self.order_settings.sl_type
            == sl_settings.ManagedOrderSettingsSLTypes.BASED_ON_INDICATOR_DESCRIPTION
        ):
            indicator_value = sl_sources.get_sl_indicator(
                ctx, maker, self.managed_order_root_path
            )
        await managed_orders.managed_order(
            ctx,
            trading_side=self.trading_side,
            orders_settings=self.order_settings,
            sl_indicator_value=indicator_value,
        )

    async def set_managed_order_settings(self, ctx, maker):
        await basic_keywords.user_input(
            ctx,
            self.managed_order_root_name,
            "object",
            title=self.managed_order_root_name.replace("_", " "),
            def_val=None,
            other_schema_values={"grid_columns": 12, "display_as_tab": True}
            # path=self.managed_order_root_path,
        )
        self.order_settings = await managed_orders.activate_managed_orders(
            ctx,
            parent_input_name=self.managed_order_root_name,
            order_tag_prefix=f"Strategy {self.strategy_id}",
        )
        if (
            self.order_settings.sl_type
            == sl_settings.ManagedOrderSettingsSLTypes.BASED_ON_INDICATOR_DESCRIPTION
        ):
            await sl_sources.activate_sl_indicator(maker, self.managed_order_root_path)
        if (
            self.order_settings.sl_trail_type
            == sl_settings.ManagedOrderSettingsSLTrailTypes.TRAILING_INDICATOR_DESCRIPTION
        ):
            await sl_sources.activate_trailing_sl_indicator(
                maker, self.managed_order_root_path
            )

    async def handle_trailing_stop(self, ctx, maker):
        if (
            self.order_settings.sl_trail_type
            != sl_settings.ManagedOrderSettingsSLTrailTypes.DONT_TRAIL_DESCRIPTION
        ):
            sl_indicator_value = None
            sl_trailing_indicator_value = None
            try:
                if (
                    self.order_settings.sl_trail_type
                    == sl_settings.ManagedOrderSettingsSLTrailTypes.TRAILING_INDICATOR_DESCRIPTION
                ):
                    sl_trailing_indicator_value = sl_sources.get_trailing_sl_indicator(
                        ctx, maker, self.managed_order_root_path
                    )
                elif (
                    self.order_settings.sl_trail_type
                    == sl_settings.ManagedOrderSettingsSLTrailTypes.TRAILING_DESCRIPTION
                    and self.order_settings.sl_type
                    == sl_settings.ManagedOrderSettingsSLTypes.BASED_ON_INDICATOR_DESCRIPTION
                ):
                    sl_indicator_value = sl_sources.get_sl_indicator(
                        ctx, maker, self.managed_order_root_path
                    )
                await stop_loss_handling.trail_stop_losses(
                    ctx,
                    self.order_settings,
                    sl_indicator_value=sl_indicator_value,
                    sl_trailing_indicator_value=sl_trailing_indicator_value,
                )
            except Exception as error:
                raise RuntimeError(
                    "Managed Order trailing Stop: There is probably an "
                    "issue in your Managed Order "
                    "configuration. Check the settings: " + str(error)
                ) from error
