# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.indicators.indicators_base as indicators_base


async def get_configurable_indicator(maker, evaluator, indicator_id: int = 1):
    indicator: indicators_base.Indicator = evaluator.indicators[indicator_id]
    return await indicator.get_indicator_data(maker, evaluator=evaluator)


async def activate_configurable_indicator(
    maker,
    evaluator,
    data_source_name="Data Source",
    def_val="EMA",
    indicator_id=1,
    enable_oscillators=True,
    enable_price_indicators=True,
    enable_price_data=True,
    enable_volume=True,
    enable_static_value=True,
    enable_force_def_val=False,
):
    indicator = indicators_base.Indicator()
    await indicator.init_indicator(
        maker,
        evaluator,
        data_source_name,
        def_val,
        indicator_id,
        enable_oscillators,
        enable_price_indicators,
        enable_price_data,
        enable_volume,
        enable_static_value,
        enable_force_def_val,
    )
    maker.indicators[indicator.cache_path] = evaluator.indicators[
        indicator_id
    ] = indicator
    return evaluator.indicators[indicator_id].indicator_name
