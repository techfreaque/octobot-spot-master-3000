# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

from tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.data.public_exchange_data import (
    get_candles_,
)
from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.indicators.indicator_handling import (
    activate_configurable_indicator,
    get_configurable_indicator,
)
from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.key_words.indicators.pivots_lib.multi_pivots_lib import (
    pivot_lows_,
    pivot_highs_,
)
from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.key_words.indicators.plotting import (
    store_indicator_data,
    allow_enable_plot,
)
from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.key_words.plots import (
    plotting,
)
from tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.user_inputs2 import (
    user_input2,
)


async def get_pivots(maker, indicator, evaluator):
    selected_indicator = await activate_configurable_indicator(
        maker,
        indicator,
        def_val="price_data",
        data_source_name="data source for pivots",
    )
    pivot_lookback = evaluator.pivot_lookback or await user_input2(
        maker, indicator, f"pivot lookback length", "int", 2, 1
    )

    pivot_low_active = await user_input2(
        maker,
        indicator,
        f"activate pivot lows",
        def_val=True,
        input_type="boolean",
        show_in_summary=False,
    )
    pivot_high_active = await user_input2(
        maker,
        indicator,
        f"activate pivot highs",
        def_val=True,
        input_type="boolean",
        show_in_summary=False,
    )
    await allow_enable_plot(maker, indicator, f"plot {selected_indicator} Pivots")

    (
        data_source_values,
        chart_location,
        data_source_title,
    ) = await get_configurable_indicator(maker, indicator)

    data = {
        "v": {
            "title": f"{data_source_title} pivots (lb:{pivot_lookback})",
            "data": {},
            "chart_location": chart_location,
        }
    }
    if pivot_low_active:
        pivot_low_data = pivot_lows_(data_source_values, swing_history=pivot_lookback)
        await _get_pivots(
            maker,
            indicator,
            data,
            data_source_title,
            chart_location,
            data_source_values,
            pivot_low_data,
            pivot_lookback,
            key="low",
        )
    if pivot_high_active:
        pivot_low_data = pivot_highs_(data_source_values, swing_history=pivot_lookback)
        await _get_pivots(
            maker,
            indicator,
            data,
            data_source_title,
            chart_location,
            data_source_values,
            pivot_low_data,
            pivot_lookback,
            key="high",
        )

    return await store_indicator_data(maker, indicator, data, force_plot_disable=True)


async def _get_pivots(
    maker,
    indicator,
    data,
    data_source_title,
    chart_location,
    data_source_values,
    pivot_data,
    pivot_lookback,
    key="low",
):
    cache_key = key + "s"
    pivot_low_title = f"{data_source_title} pivot {key} (lb {pivot_lookback})"
    # format data and store
    cut_source_values = data_source_values[:-pivot_lookback]
    data["v"]["data"][key] = {
        "title": pivot_low_title,
        "pivots": pivot_data,
        "pivots_val": cut_source_values,
        "values": data_source_values,
    }
    if indicator.plot:
        if maker.is_backtesting or (
            not maker.is_backtesting and not maker.live_recording_mode
        ):
            data_len = min([len(pivot_data), len(cut_source_values)])
            t = await get_candles_(maker, "time")
            t = t
            pivots_to_store = {"time": [], cache_key: []}
            for index in range(1, data_len):
                if pivot_data[-index]:
                    pivots_to_store["time"].append(t[-index])
                    pivots_to_store[cache_key].append(cut_source_values[-index])
            await maker.ctx.set_cached_values(
                values=pivots_to_store[cache_key],
                value_key=indicator.config_path_short + cache_key,
                cache_keys=pivots_to_store[cache_key],
            )
        else:
            if pivot_data[-1]:
                await maker.ctx.set_cached_value(
                    value=list(cut_source_values)[-1],
                    value_key=indicator.config_path_short + cache_key,
                )
        await plotting.plot(
            maker.ctx,
            data["v"]["title"],
            cache_value=indicator.config_path_short + cache_key,
            chart=chart_location,
            color="red",
            mode="markers",
        )
