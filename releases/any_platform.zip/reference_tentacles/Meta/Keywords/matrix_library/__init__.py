from octobot_tentacles_manager.api.inspector import check_tentacle_version
from octobot_commons.logging.logging_util import get_logger

if check_tentacle_version("0.5.1", "matrix_basic_keywords", "Matrix-Basic-Keywords"):
    try:
        from .matrix_basic_keywords import *
    except Exception as e:
        get_logger("TentacleLoader").error(
            f"Error when loading matrix_basic_keywords: "
            f'{e.__class__.__name__}{f" ({e})" if f"{e}" else ""}. If this '
            f"error persists, try reinstalling your tentacles via "
            f'"python start.py tentacles --install --all".'
        )

if check_tentacle_version("0.5.1", "matrix_pro_keywords", "Matrix-Pro-Keywords"):
    try:
        from .matrix_pro_keywords import *
    except Exception as e:
        get_logger("TentacleLoader").error(
            f"Error when loading matrix_pro_keywords: "
            f'{e.__class__.__name__}{f" ({e})" if f"{e}" else ""}. If this '
            f"error persists, try reinstalling your tentacles via "
            f'"python start.py tentacles --install --all".'
        )

if check_tentacle_version(
    "0.5.1", "matrix_strategy_maker_keywords", "Matrix-Strategy-Maker-Keywords"
):
    try:
        from .matrix_strategy_maker_keywords import *
    except Exception as e:
        get_logger("TentacleLoader").error(
            f"Error when loading matrix_strategy_maker_keywords: "
            f'{e.__class__.__name__}{f" ({e})" if f"{e}" else ""}. If this '
            f"error persists, try reinstalling your tentacles via "
            f'"python start.py tentacles --install --all".'
        )

if check_tentacle_version(
    "0.5.1", "RunAnalysis", "Matrix-Strategy-Maker-Keywords"
):
    try:
        from .RunAnalysis import *
    except Exception as e:
        get_logger("TentacleLoader").error(
            f"Error when loading RunAnalysis: "
            f'{e.__class__.__name__}{f" ({e})" if f"{e}" else ""}. If this '
            f"error persists, try reinstalling your tentacles via "
            f'"python start.py tentacles --install --all".'
        )
