# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import decimal
import matplotlib.pyplot as plt

from tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.orders.scaled_orders import (
    calculate_scaled_growth_orders,
)


def test_scaled_order():
    amount_of_orders = 10
    total_amount = decimal.Decimal("10000")
    growth_factors = [
        1,
        1.1,
        1.2,
        1.3,
        1.5,
        1.5,
        2,
        2.5,
        3,
        3.5,
        4,
        4.5,
        5,
        6,
        7,
        8,
        9,
        10,
        20,
        30,
        40,
        50,
    ]
    power = 10
    y_mode_inverted = True
    # growth_type = "exponential"
    # scaled_order_test(
    #     growth_type=growth_type,
    #     amount_of_orders=amount_of_orders,
    #     growth_factors=growth_factors,
    #     total_amount=total_amount,
    #     y_mode_inverted=y_mode_inverted,
    #     power=power,
    # )
    growth_type = "linear_growth"
    scaled_order_test(
        growth_type=growth_type,
        amount_of_orders=amount_of_orders,
        growth_factors=growth_factors,
        total_amount=total_amount,
        y_mode_inverted=y_mode_inverted,
    )


def scaled_order_test(
    growth_type,
    growth_factors,
    total_amount,
    y_mode_inverted=False,
    power=None,
    amount_of_orders=None,
):

    # plot
    fig, ax = plt.subplots()
    normal_y = []
    for i in range(amount_of_orders):
        normal_y.append(i)
    y = x = None
    if y_mode_inverted:
        x = normal_y
        plt.xlabel("Order number")
        plt.ylabel("Order amount (in % of total order amount)")
    else:
        y = normal_y
        plt.ylabel("Order number")
        plt.xlabel("Order amount (in % of total order amount)")
    x_lim = 0
    for growth_factor in growth_factors:
        normalized_values = calculate_scaled_growth_orders(
            total_value=total_amount,
            amount_of_orders=amount_of_orders,
            growth_factor=growth_factor,
            growth_type=growth_type,
            power=power,
        )
        if y_mode_inverted:
            y = normalized_values
        else:
            x = normalized_values
        x_lim = normalized_values[-1] if x_lim < normalized_values[-1] else x_lim
        # plot
        ax.plot(
            x,
            y,
            linewidth=2.0,
            label=f"growth_factor: {growth_factor} - amount of orders: {amount_of_orders}",
        )
    # ax.set(xlim=(0, x_lim))

    plt.legend()
    plt.show()
