# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import decimal
import numpy
import tentacles.Meta.Keywords.scripting_library.orders.order_types.create_order as create_order
import tentacles.Meta.Keywords.scripting_library.orders.position_size as position_size
import tentacles.Meta.Keywords.scripting_library.orders.offsets as offsets


class ScaledOrderValueDistributionTypes:
    FLAT = "flat"  # all orders have the same amount
    LINEAR_GROWTH = "linear_growth"  # order value will grow linear
    EXPONENTIAL = "exponential"  # order value will grow exponential
    all_types = [FLAT, LINEAR_GROWTH]


class ScaledOrderPriceDistributionTypes:
    FLAT = "flat"  # all orders have the same distance
    LINEAR_GROWTH = "linear_growth"
    EXPONENTIAL = "exponential"
    all_types = [FLAT, LINEAR_GROWTH]


async def scaled_order(
    context,
    side=None,
    symbol=None,
    order_type_name="limit",
    scale_from=None,
    scale_to=None,
    order_count=10,
    value_distribution_type=ScaledOrderValueDistributionTypes.FLAT,
    price_distribution_type=ScaledOrderPriceDistributionTypes.FLAT,
    value_growth_factor=2,
    price_growth_factor=2,
    # either amount, value, target_position or position_size_calculator
    amount=None,
    value: decimal.Decimal = None,  # value in ref market
    target_position=None,
    position_size_calculator=None,
    # either stop_loss_calculator or stop_loss_offset
    stop_loss_calculator=None,
    stop_loss_calculator_bundling=False,
    stop_loss_offset=None,
    stop_loss_tag=None,
    stop_loss_type=None,
    stop_loss_group=None,
    # either offset or take_profit_calculator
    take_profit_offset=None,
    take_profit_calculator=None,
    take_profit_tag=None,
    take_profit_type=None,
    take_profit_group=None,
    slippage_limit=None,
    time_limit=None,
    reduce_only=False,
    post_only=False,
    tag=None,
    group=None,
    wait_for=None,
):
    entry_prices, stop_loss_prices, order_amounts = await calculate_scaled_order(
        context=context,
        side=side,
        order_type_name=order_type_name,
        scale_from=scale_from,
        scale_to=scale_to,
        order_count=order_count,
        value_distribution_type=value_distribution_type,
        price_distribution_type=price_distribution_type,
        value_growth_factor=value_growth_factor,
        price_growth_factor=price_growth_factor,
        amount=amount,
        value=value,
        position_size_calculator=position_size_calculator,
        stop_loss_calculator=stop_loss_calculator,
        target_position=target_position,
        reduce_only=reduce_only,
        wait_for=wait_for,
    )
    created_orders = []
    take_profit_prices = []
    for order_index, entry_price in enumerate(entry_prices):
        if take_profit_calculator:
            take_profit_prices.append(
                take_profit_calculator(
                    entry_price,
                    stop_loss_prices[order_index] if stop_loss_prices else None,
                )
            )
            if take_profit_prices[-1]:
                take_profit_offset = f"@{take_profit_prices[-1]}"
        if take_profit_tag:
            take_profit_tag = take_profit_tag + f" {order_index+1}/{order_count}"
        if stop_loss_calculator and stop_loss_calculator_bundling:
            stop_loss_offset = f"@{stop_loss_prices[order_index]}"
        new_created_order = await create_order.create_order_instance(
            context,
            side=side,
            symbol=symbol or context.symbol,
            order_amount=order_amounts[order_index],
            order_type_name=order_type_name,
            order_offset=f"@{entry_price}",
            stop_loss_offset=stop_loss_offset,
            stop_loss_tag=stop_loss_tag,
            stop_loss_type=stop_loss_type,
            stop_loss_group=stop_loss_group,
            take_profit_offset=take_profit_offset,
            take_profit_tag=take_profit_tag,
            take_profit_type=take_profit_type,
            take_profit_group=take_profit_group,
            slippage_limit=slippage_limit,
            time_limit=time_limit,
            reduce_only=reduce_only,
            post_only=post_only,
            group=group,
            tag=tag,
            wait_for=wait_for,
        )
        try:
            created_orders.append(new_created_order[0])
        except IndexError as error:
            raise RuntimeError(
                f"Scaled {side} order failed to create orders"
            ) from error
    return (
        created_orders,
        entry_prices,
        stop_loss_prices,
        take_profit_prices,
        order_amounts,
    )


async def calculate_scaled_order(
    context,
    order_type_name,
    side=None,
    scale_from=None,
    scale_to=None,
    order_count=10,
    value_distribution_type=ScaledOrderValueDistributionTypes.FLAT,
    price_distribution_type=ScaledOrderPriceDistributionTypes.FLAT,
    value_growth_factor=2,
    price_growth_factor=2,
    # either amount, value, target_position or position_size_calculator
    amount=None,
    value: decimal.Decimal = None,  # value in ref market
    position_size_calculator=None,
    target_position=None,
    stop_loss_calculator=None,
    reduce_only=False,
    wait_for=None,
):
    total_amount = None
    unknown_portfolio_on_creation = wait_for is not None

    if (amount is not None and side is not None) and (
        target_position is None and value is None and position_size_calculator is None
    ):
        total_amount = await position_size.get_amount(
            context,
            amount,
            side=side,
            use_total_holding=True,
            unknown_portfolio_on_creation=unknown_portfolio_on_creation,
        )

    elif target_position is not None and (
        amount is None
        and side is None
        and value is None
        and position_size_calculator is None
    ):
        total_amount, side = await position_size.get_target_position(
            context,
            target_position,
            reduce_only=reduce_only,
            unknown_portfolio_on_creation=unknown_portfolio_on_creation,
        )
    elif (value is not None and side is not None) and (
        amount is None and target_position is None and position_size_calculator is None
    ):
        pass
    elif (position_size_calculator is not None and side is not None) and (
        amount is None and target_position is None and value is None
    ):
        pass

    else:
        raise RuntimeError(
            "Scaled order supports either (side with amount), (target_position), "
            "(side with position_size_calculator) or "
            "(side with value in reference market). "
            "Not required parameters must be set to none "
        )

    scale_from_price = await offsets.get_offset(context, scale_from, side=side)
    scale_to_price = await offsets.get_offset(context, scale_to, side=side)
    normalized_scale_from_price, normalized_scale_to_price = get_normalized_scale(
        scale_from_price, scale_to_price, side
    )

    # price_distribution_types
    entry_prices: list = []
    stop_loss_prices: list = []
    distance_factors: list = []
    if price_distribution_type == "linear_growth":
        distance_factors = calculate_linear_growth(
            price_growth_factor,
            1,
            # - one because start is given
            order_count - 1,
        )
        total_factor = sum(distance_factors)
        from_to_distance = normalized_scale_to_price - normalized_scale_from_price
        prev_price = normalized_scale_from_price
        entry_prices.append(normalized_scale_from_price)

        if stop_loss_calculator:
            sl_price, _ = await stop_loss_calculator(
                trading_side=side,
                average_entry_price=float(str(normalized_scale_from_price)),
            )
            if sl_price is not None:
                stop_loss_prices.append(decimal.Decimal(str(sl_price)))

        for factor in distance_factors:
            multiplier = 100 / total_factor  # 100%
            percent_of_total_factor = decimal.Decimal(str((factor * multiplier) / 100))
            entry_prices.append(
                (percent_of_total_factor * from_to_distance) + prev_price
            )
            prev_price = entry_prices[-1]
            if stop_loss_calculator:
                sl_price, _ = await stop_loss_calculator(
                    trading_side=side,
                    average_entry_price=float(str(entry_prices[-1])),
                )
                if sl_price is not None:
                    stop_loss_prices.append(decimal.Decimal(str(sl_price)))

    elif price_distribution_type == "flat":
        entry_prices, stop_loss_prices = await calculate_flat_distribution(
            normalized_scale_from_price,
            normalized_scale_to_price,
            order_count,
            side,
            stop_loss_calculator,
        )
    else:
        raise RuntimeError(
            "scaled order: unsupported amount_of_orders_distribution_type. "
            "check the documentation for more informations"
        )
    # value_distribution_types
    order_amounts: list = []
    if value_distribution_type == "flat":
        # distance_factors = [1] * order_count
        if value:
            value_per_order = value / order_count
            for price in entry_prices:
                order_amounts.append(value_per_order / price)
        elif total_amount:
            amount_per_order = total_amount / order_count
            order_amounts = [amount_per_order] * order_count
        elif position_size_calculator:
            # get average entry for the position site calculator
            tmp_total_value = 1000
            tmp_value_per_order = decimal.Decimal(str(tmp_total_value / order_count))
            tmp_total_quantity = 0
            stop_loss_total_value = 0
            for order_index, entry_price in enumerate(entry_prices):
                this_quantity = entry_price / tmp_value_per_order
                tmp_total_quantity += this_quantity
                stop_loss_total_value += stop_loss_prices[order_index] * this_quantity
            try:
                average_entry_price = tmp_total_value / tmp_total_quantity
            except ZeroDivisionError as error:
                raise RuntimeError(
                    "Scaled order failed to determine the average entry price"
                ) from error
            average_stop_loss_price = None
            if stop_loss_total_value:
                average_stop_loss_price = stop_loss_total_value / tmp_total_quantity
            total_amount = await position_size_calculator(
                average_entry_price=average_entry_price,
                entry_type=order_type_name,
                stop_loss_in_percent=average_stop_loss_price,
            )
            order_amounts = [total_amount / order_count] * order_count
        else:
            raise RuntimeError("Scaled order failed to determine the position size")
    elif value_distribution_type in (
        ScaledOrderValueDistributionTypes.LINEAR_GROWTH,
        ScaledOrderValueDistributionTypes.EXPONENTIAL,
    ):
        order_values = await calculate_scaled_growth_orders(
            total_value=value,
            total_amount=total_amount,
            position_size_calculator=position_size_calculator,
            order_type_name=order_type_name,
            entry_prices=entry_prices,
            amount_of_orders=order_count,
            growth_factor=value_growth_factor,
            growth_type=value_distribution_type,
            power=15,
            stop_loss_prices=stop_loss_prices,
        )
        if value:
            for index, price in enumerate(entry_prices):
                order_amounts.append(order_values[index] / price)
        else:
            order_amounts = order_values
    else:
        raise RuntimeError(
            "scaled order: unsupported value_distribution_type. "
            "check the documentation for more informations"
        )
    return entry_prices, stop_loss_prices, order_amounts


def calculate_linear_growth(scale_from, scale_to, order_count) -> list:
    _growth_array = numpy.linspace(
        start=scale_from,
        stop=scale_to,
        num=order_count,
        dtype=float,
    )
    return _growth_array


async def calculate_flat_distribution(
    scale_from, scale_to, count: int, trading_side: str, stop_loss_calculator
) -> list:
    entry_prices = []
    stop_loss_prices = []
    if scale_from >= scale_to:
        price_difference = scale_from - scale_to
        step_size = price_difference / (count - 1)
        for i in range(0, count):
            entry_prices.append(scale_from - (step_size * i))
            if stop_loss_calculator:
                sl_price, _ = await stop_loss_calculator(
                    trading_side=trading_side,
                    average_entry_price=float(str(entry_prices[-1])),
                )
                if sl_price is not None:
                    stop_loss_prices.append(decimal.Decimal(str(sl_price)))
    elif scale_to > scale_from:
        price_difference = scale_to - scale_from
        step_size = price_difference / (count - 1)
        for i in range(0, count):
            entry_prices.append(scale_from + (step_size * i))
            if stop_loss_calculator:
                sl_price, _ = await stop_loss_calculator(
                    trading_side=trading_side,
                    average_entry_price=float(str(entry_prices[-1])),
                )
                if sl_price is not None:
                    stop_loss_prices.append(decimal.Decimal(str(sl_price)))
    return entry_prices, stop_loss_prices


def get_normalized_scale(scale_from_price, scale_to_price, side) -> tuple:
    normalized_scale_from_price: decimal.Decimal = None
    normalized_scale_to_price: decimal.Decimal = None
    if scale_from_price == scale_to_price:
        raise RuntimeError("scale_from_price and scale_to_price cant be the same")
    if scale_from_price > scale_to_price:
        if side == "buy":
            # from is higher
            normalized_scale_from_price = scale_from_price
            # to is lower
            normalized_scale_to_price = scale_to_price
        else:  # sell
            # from is lower
            normalized_scale_from_price = scale_to_price
            # to is higher
            normalized_scale_to_price = scale_from_price
    elif scale_to_price > scale_from_price:
        if side == "buy":
            # from is higher
            normalized_scale_from_price = scale_to_price
            # to is lower
            normalized_scale_to_price = scale_from_price
        else:  # sell
            # from is lower
            normalized_scale_from_price = scale_from_price
            # to is higher
            normalized_scale_to_price = scale_to_price
    return normalized_scale_from_price, normalized_scale_to_price


async def calculate_scaled_growth_orders(
    total_value: decimal.Decimal = None,
    total_amount: decimal.Decimal = None,
    position_size_calculator=None,
    order_type_name: str = "limit",
    amount_of_orders: int = 10,
    growth_factor: float = 2,
    growth_type="linear_growth",
    power: int = 15,
    stop_loss_prices: list = None,
    entry_prices: list = None,
):

    SUM_OF_ARRAY = 100
    _array_start = SUM_OF_ARRAY / amount_of_orders
    _array_end = SUM_OF_ARRAY / amount_of_orders * growth_factor
    if growth_type == "linear_growth":
        _growth_array = calculate_linear_growth(
            _array_start, _array_end, amount_of_orders
        )
    elif growth_type == "exponential":

        def func(x, adj1, adj2):
            return ((x + adj1) ** power) * adj2

        # two given datapoints to which the exponential
        # function with power pw should fit
        x = [
            _array_start,
            _array_end,
        ]
        y = [1, amount_of_orders]

        A = numpy.exp(numpy.log(y[0] / y[1]) / power)
        a = (x[0] - x[1] * A) / (A - 1)
        b = y[0] / (x[0] + a) ** power
        xf = numpy.linspace(1, amount_of_orders, amount_of_orders)
        _growth_array = func(xf, a, b)
    else:
        # Handle other growth types here
        raise NotImplementedError()

    growth_array_sum = 0
    growth_deci_array = []
    for number in _growth_array:
        growth_deci_array.append(decimal.Decimal(str(number)))
        growth_array_sum += growth_deci_array[-1]

    if position_size_calculator:
        # get average entry for the position site calculator
        tmp_total_quantity = 0
        stop_loss_total_value = 0
        for order_index, entry_price in enumerate(entry_prices):
            this_quantity = entry_price / growth_deci_array[order_index]
            tmp_total_quantity += this_quantity
            if len(stop_loss_prices):
                stop_loss_total_value += stop_loss_prices[order_index] * this_quantity
        try:
            average_entry_price = growth_array_sum / tmp_total_quantity
        except ZeroDivisionError as error:
            raise RuntimeError(
                "Scaled order failed to determine the average entry price"
            ) from error
        average_stop_loss_price = None
        if stop_loss_total_value:
            average_stop_loss_price = stop_loss_total_value / tmp_total_quantity
        total_amount = decimal.Decimal(
            str(
                await position_size_calculator(
                    average_entry_price=average_entry_price,
                    entry_type=order_type_name,
                    stop_loss_in_percent=average_stop_loss_price,
                )
            )
        )

    normalized_amount = []
    for number in growth_deci_array:
        normalized_amount.append(
            total_amount * ((number / (growth_array_sum / 100)) / 100)
        )
    return normalized_amount
