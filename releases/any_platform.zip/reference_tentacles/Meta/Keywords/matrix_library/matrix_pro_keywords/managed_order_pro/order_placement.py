# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import decimal
import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import octobot_trading.enums as trading_enums
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.entry_settings as entry_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings as sl_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.tp_settings as tp_settings
from tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.stop_losses import (
    stop_loss_handling,
)
from tentacles.Meta.Keywords.scripting_library.data.reading import exchange_public_data
import tentacles.Meta.Keywords.scripting_library.orders.order_types as order_types
import tentacles.Meta.Keywords.scripting_library.orders.grouping as grouping
import tentacles.Meta.Keywords.scripting_library.orders.waiting as waiting
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.position_sizing as position_sizing
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.take_profits.take_profits as take_profits
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.orders.scaled_orders as scaled_orders


class ManagedOrderPlacement(position_sizing.ManagedOrderPositionSizing):
    def __init__(self):
        super().__init__()
        self.sl_offset = None
        self.sl_tag = None
        self.entry_type = ""
        self.profit_in_p = 0
        self.profit_in_d = 0
        self.take_profit_data: take_profits.ManagedOrderTakeProfit = None
        self.average_entry_price: float = None
        self.entry_quantity: float = None

    async def place_managed_entry_and_exits(self, ctx):
        # ensure leverage is up to date
        await basic_keywords.user_select_leverage(ctx)
        await basic_keywords.set_partial_take_profit_stop_loss(ctx)

        # create order group if necessary
        await self.handle_manged_order_group(ctx)

        self.current_price_val = float(
            await exchange_public_data.current_live_price(ctx)
        )
        self.set_managed_order_tags()

        # calculate tp
        take_profit_calculator = self.get_take_profits_calculator()
        bundled_tp_calculator = None
        bundled_tp_tag: str = None
        bundled_tp_order_group = None
        if (
            tp_settings.ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION
            != self.managed_orders_settings.tp_type
        ):
            if self.managed_orders_settings.use_bundled_sl_orders:
                bundled_tp_calculator = take_profit_calculator
                bundled_tp_order_group = self.order_group
                bundled_tp_tag = self.exit_order_tag

        # stop loss
        is_bundled_sl = False
        bundled_sl_tag: str = None
        bundled_sl_order_group = None
        if (
            sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
            != self.managed_orders_settings.sl_type
        ):
            self.sl_offset = f"@{self.sl_price}"
            self.sl_tag = self.exit_order_tag
            if self.managed_orders_settings.use_bundled_sl_orders:
                is_bundled_sl = True
                bundled_sl_tag = self.sl_tag
                bundled_sl_order_group = self.order_group

        async def stop_loss_calculator(trading_side, average_entry_price):
            if (
                self.managed_orders_settings.sl_type
                != sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
            ):
                return await stop_loss_handling.get_manged_order_stop_loss(
                    ctx=ctx,
                    managed_orders_settings=self.managed_orders_settings,
                    trading_side=trading_side,
                    sl_indicator_value=self.sl_indicator_value,
                    entry_price=average_entry_price,
                )
                # no SL
            return None, None

        async def position_size_calculator(
            average_entry_price: float, entry_type: str, stop_loss_in_percent: float
        ):
            await self.set_managed_position_size(
                ctx,
                entry_price=average_entry_price,
                entry_order_type=entry_type,
                stop_loss_in_percent=stop_loss_in_percent,
            )
            if self.place_entries:
                await self.handle_order_recreate_mode(ctx)
                return self.position_size
            return None

        # entry

        self.entry_type = "market"
        if (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SINGLE_TRY_LIMIT_IN_DESCRIPTION
        ):
            # entry try limit in
            # todo + handle on backtesting (maybe use always 1m to check if it got filled)
            # entry_type = "limit"
            # created_orders = await order_types.trailing_limit(ctx, amount=position_size_limit, side=entry_side,
            #                                                   min_offset=0, max_offset=0,
            #                                                   slippage_limit=self.managed_orders_settings.slippage_limit,
            #                                                   tag=entry_order_tag, stop_loss_offset=sl_offset,
            #                                                   stop_loss_tag=sl_tag)
            # # wait for limit to get filled
            # if tag_triggered.tagged_order_unfilled(entry_order_tag):
            #     unfilled_amount = tag_triggered.tagged_order_unfilled_amount(entry_order_tag)
            #     if unfilled_amount != position_size_limit:
            #         position_size_market = 50  # todo calc smaller size cause of fees
            #     created_orders = await order_types.market(ctx, side=entry_side, amount=position_size_market,
            #                                               tag=entry_order_tag, stop_loss_offset=sl_offset,
            #                                               stop_loss_tag=sl_tag)
            raise NotImplementedError("managed order: try limit in not implemented yet")

        # entry market in only
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION
        ):
            self.sl_price, self.sl_in_p = await stop_loss_calculator(
                trading_side=self.trading_side,
                average_entry_price=self.current_price_val,
            )
            await position_size_calculator(
                average_entry_price=self.current_price_val,
                entry_type=self.entry_type,
                stop_loss_in_percent=self.sl_in_p,
            )
            if self.place_entries:
                self.created_orders = await order_types.market(
                    ctx,
                    side=self.entry_side,
                    amount=self.position_size,
                    tag=self.entry_order_tag,
                    stop_loss_offset=get_bundled_sl_offset(
                        stop_loss_price=self.sl_price, is_bundled=is_bundled_sl
                    ),
                    stop_loss_tag=bundled_sl_tag,
                    stop_loss_group=bundled_sl_order_group,
                    take_profit_offset=get_bundled_tp_offset(
                        bundled_tp_calculator, self.current_price_val, self.sl_price
                    ),
                    take_profit_tag=bundled_tp_tag,
                    take_profit_group=bundled_tp_order_group,
                )

        # entry limit in only
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SINGLE_LIMIT_IN_DESCRIPTION
        ):
            self.entry_type = "limit"
            if self.entry_side == "buy":
                self.average_entry_price = self.current_price_val * (
                    1 - (self.managed_orders_settings.limit_offset / 100)
                )
            else:
                self.average_entry_price = self.current_price_val * (
                    1 + (self.managed_orders_settings.limit_offset / 100)
                )

            self.sl_price, self.sl_in_p = await stop_loss_calculator(
                trading_side=self.trading_side,
                average_entry_price=self.average_entry_price,
            )
            await position_size_calculator(
                average_entry_price=self.average_entry_price,
                entry_type=self.entry_type,
                stop_loss_in_percent=self.sl_in_p,
            )
            if self.place_entries:
                self.created_orders = await order_types.limit(
                    ctx,
                    side=self.entry_side,
                    amount=self.position_size,
                    offset=f"@{self.average_entry_price}",
                    tag=self.entry_order_tag,
                    stop_loss_offset=get_bundled_sl_offset(
                        stop_loss_price=self.sl_price, is_bundled=is_bundled_sl
                    ),
                    stop_loss_tag=bundled_sl_tag,
                    stop_loss_group=bundled_sl_order_group,
                    take_profit_offset=get_bundled_tp_offset(
                        bundled_tp_calculator, self.average_entry_price, self.sl_price
                    ),
                    take_profit_tag=bundled_tp_tag,
                    take_profit_group=bundled_tp_order_group,
                )

        # # entry scaled limits
        # elif (
        #     self.managed_orders_settings.entry_type
        #     == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION
        # ):
        #     self.entry_type = "limit"
        #     if self.entry_side == trading_enums.TradeOrderSide.BUY.value:
        #         scale_from = f"-{self.managed_orders_settings.entry_scaled_max}%"
        #         scale_to = f"-{self.managed_orders_settings.entry_scaled_min}%"
        #     else:
        #         scale_from = f"{self.managed_orders_settings.entry_scaled_min}%"
        #         scale_to = f"{self.managed_orders_settings.entry_scaled_max}%"
        #     self.created_orders = []
        #     for grid in self.managed_orders_settings.entry_grids.values():
        #         (
        #             created_orders,
        #             entry_prices,
        #             stop_loss_prices,
        #             take_profit_prices,
        #             order_amounts,
        #         ) = await scaled_orders.scaled_order(
        #             ctx,
        #             side=self.entry_side,
        #             position_size_calculator=position_size_calculator,
        #             stop_loss_calculator_bundling=True if bundled_sl_tag else False,
        #             scale_from=scale_from,
        #             scale_to=scale_to,
        #             order_count=self.managed_orders_settings.entry_scaled_order_count,
        #             tag=self.entry_order_tag,
        #             stop_loss_calculator=stop_loss_calculator,
        #             stop_loss_tag=bundled_sl_tag,
        #             stop_loss_group=bundled_sl_order_group,
        #             take_profit_calculator=bundled_tp_calculator,
        #             take_profit_tag=bundled_tp_tag,
        #             take_profit_group=bundled_tp_order_group,
        #             value_distribution_type=grid.value_distribution_type,
        #             value_growth_factor=grid.value_growth_factor,
        #             price_distribution_type=grid.price_distribution_type,
        #             price_growth_factor=grid.price_growth_factor,
        #         )
        #         self.created_orders += created_orders

        # entry grid limits
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_STATIC_DESCRIPTION
            or self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION
        ):
            self.entry_type = "limit"
            self.created_orders = []
            for grid in self.managed_orders_settings.entry_grids.values():
                if (
                    self.managed_orders_settings.entry_type
                    == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION
                ):
                    if self.entry_side == trading_enums.TradeOrderSide.BUY.value:
                        scale_from = f"-{grid.from_level}%"
                        scale_to = f"-{grid.to_level}%"
                    else:
                        scale_from = f"{grid.from_level}%"
                        scale_to = f"{grid.to_level}%"
                else:
                    scale_from = f"@{grid.from_level}"
                    scale_to = f"@{grid.to_level}"
                (
                    created_orders,
                    entry_prices,
                    stop_loss_prices,
                    take_profit_prices,
                    order_amounts,
                ) = await scaled_orders.scaled_order(
                    ctx,
                    side=self.entry_side,
                    scale_from=scale_from,
                    scale_to=scale_to,
                    order_count=grid.order_count,
                    tag=self.entry_order_tag,
                    position_size_calculator=position_size_calculator,
                    stop_loss_calculator_bundling=True if bundled_sl_tag else False,
                    stop_loss_calculator=stop_loss_calculator,
                    stop_loss_tag=bundled_sl_tag,
                    stop_loss_group=bundled_sl_order_group,
                    take_profit_calculator=bundled_tp_calculator,
                    take_profit_tag=bundled_tp_tag,
                    take_profit_group=bundled_tp_order_group,
                    value_distribution_type=grid.value_distribution_type,
                    value_growth_factor=grid.value_growth_factor,
                    price_distribution_type=grid.price_distribution_type,
                    price_growth_factor=grid.price_growth_factor,
                )
                self.created_orders += created_orders

        # entry time grid orders
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_OVER_TIME_DESCRIPTION
        ):
            raise NotImplementedError("time grid orders not implemented yet")
        else:
            raise NotImplementedError("Unknown entry order type")

        if not self.created_orders or (
            self.created_orders[0] is None and len(self.created_orders) == 1
        ):
            # no entry created: do not create exits
            return

        if not ctx.exchange_manager.is_backtesting and self.entry_type == "market":
            pass
            # TODO wait for filled market price and actual quantity for all orders
            # TODO wait for updated entry price

        if len(self.created_orders) > 1:
            quantity = decimal.Decimal("0")
            total_position_cost = decimal.Decimal("0")
            for order in self.created_orders:
                quantity += order.origin_quantity
                total_position_cost += order.origin_quantity * order.origin_price
            self.entry_quantity = float(str(quantity))
            self.average_entry_price = (
                float(str(total_position_cost)) / self.entry_quantity
            )
        else:
            self.entry_quantity = float(str(self.created_orders[0].origin_quantity))
            self.average_entry_price = float(str(self.created_orders[0].origin_price))

        # TODO migrate modify orders
        # # in real treading wait for orders and modify SL if necessary
        # if (
        #     ctx.exchange_manager.trader.trader_type_str
        #     == trading_constants.REAL_TRADER_STR
        #     and self.managed_orders_settings.adapt_live_exits
        # ):
        #     await self.handle_managed_real_trading_orders(ctx)

        # TODO self.entry_quantity and self.average_entry_price
        if (
            sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
            != self.managed_orders_settings.sl_type
            and self.created_orders
            and not self.managed_orders_settings.use_bundled_sl_orders
        ):

            # todo make sure it uses quantity for all orders
            await order_types.stop_loss(
                ctx,
                side=self.exit_side,
                offset=self.sl_offset,
                amount=self.entry_quantity,
                tag=self.sl_tag,
                group=self.order_group,
            )

        # create non bundled exit orders
        if not self.managed_orders_settings.use_bundled_tp_orders:
            await self.place_managed_take_profits(
                ctx,
                take_profit_calculator,
            )

        if self.enabled_order_group:
            # activate one cancels the other side for tp and sl
            for order in self.created_orders:
                order.trader = ctx.trader
            await grouping.enable_group(self.order_group, True)

        return self

    def get_stop_loss_calculator(self):
        # SL
        if (
            self.managed_orders_settings.sl_type
            != sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
        ):
            # no SL
            return stop_loss_handling.get_manged_order_stop_loss
        return None

    def get_take_profits_calculator(self):
        # take profits
        if (
            tp_settings.ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION
            != self.managed_orders_settings.tp_type
        ):
            # take profit based on risk reward
            if (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION
            ):

                def take_profit_calculator(entry_price, stop_loss_in_percent):
                    return take_profits.calculate_take_profit_based_on_risk_reward(
                        self, entry_price, stop_loss_in_percent
                    )

            # # scaled take profit based on risk reward
            # elif (
            #     self.managed_orders_settings.tp_type
            #     == tp_settings.ManagedOrderSettingsTPTypes.SCALED_RISK_REWARD_DESCRIPTION
            # ):

            #     def take_profit_calculator(entry_price):
            #         take_profits.calculate_take_profit_scaled_based_on_risk_reward(
            #             self, entry_price
            #         )

            # take profit based on percent
            elif (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION
            ):

                def take_profit_calculator(entry_price, stop_loss_in_percent):
                    return take_profits.calculate_take_profit_based_on_percent(
                        self, entry_price, stop_loss_in_percent
                    )

            # # scaled take profit based on percent
            # elif (
            #     self.managed_orders_settings.tp_type
            #     == tp_settings.ManagedOrderSettingsTPTypes.SCALED_PERCENT_DESCRIPTION
            # ):

            #     def take_profit_calculator(entry_price):
            #         take_profits.calculate_take_profit_scaled_based_on_percent(
            #             self, entry_price
            #         )

            # single take profit based on static price
            elif (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION
            ):

                def take_profit_calculator(entry_price, stop_loss_in_percent):
                    return take_profits.calculate_take_profit_based_on_static_price(
                        self, entry_price, stop_loss_in_percent
                    )

            else:
                return None
            return take_profit_calculator
        return None

    async def place_managed_take_profits(
        self,
        ctx,
        take_profit_calculator,
    ):
        if (
            tp_settings.ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION
            != self.managed_orders_settings.tp_type
        ):
            take_profit_data: take_profits.ManagedOrderTakeProfit = (
                take_profit_calculator(self, self.average_entry_price)
            )
            # take profit based on risk reward
            if (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION
            ):
                await take_profits.place_take_profit_based_on_risk_reward(
                    self.created_orders, ctx, take_profit_data, self.entry_quantity
                )

            # # scaled take profit based on risk reward
            # elif (
            #     self.managed_orders_settings.tp_type
            #     == tp_settings.ManagedOrderSettingsTPTypes.SCALED_RISK_REWARD_DESCRIPTION
            # ):
            #     await take_profits.place_take_profit_scaled_based_on_risk_reward(
            #         self.created_orders, ctx, take_profit_data, self.entry_quantity
            #     )

            # take profit based on percent
            elif (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION
            ):
                await take_profits.place_take_profit_based_on_percent(
                    self.created_orders, ctx, take_profit_data, self.entry_quantity
                )

            # # scaled take profit based on percent
            # elif (
            #     self.managed_orders_settings.tp_type
            #     == tp_settings.ManagedOrderSettingsTPTypes.SCALED_PERCENT_DESCRIPTION
            # ):
            #     await take_profits.place_take_profit_scaled_based_on_percent(
            #         self.created_orders, ctx, take_profit_data, self.entry_quantity
            #     )

            # single take profit based on static price
            elif (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION
            ):
                await take_profits.place_take_profit_based_on_static_price(
                    self.created_orders, ctx, take_profit_data, self.entry_quantity
                )

    async def handle_managed_real_trading_orders(self, ctx):
        if (
            sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
            != self.managed_orders_settings.sl_type
        ):
            # todo create task - takes ages and blocks from finishing - but wait for that with the notification
            if self.entry_type == "market":
                pass
                # edit stop loss to accurate values once market is filled
                # await asyncio.sleep(10)
                # try:
                #     await stop_losses.adjust_managed_stop_loss(ctx, self.managed_orders_settings, self)
                # except Exception as e:
                #     ctx.logger.error(f"Managed Order: adapting stop loss based on filled price failed. (error: {e})")
                #     self.enabled_order_group = False
                #     # in case it fails continue anyway creating take profits
            else:  # limit orders
                # for limit orders we wait for the stop loss to be placed
                await waiting.wait_for_stop_loss_open(
                    ctx, self.created_orders, timeout=60
                )


def get_bundled_tp_offset(bundled_tp_calculator, entry_price, stop_loss_price):
    if bundled_tp_calculator:
        take_profit_price = bundled_tp_calculator(
            decimal.Decimal(str(entry_price)), decimal.Decimal(str(stop_loss_price))
        )
        return f"@{take_profit_price}"
    return None


def get_bundled_sl_offset(stop_loss_price: float, is_bundled: bool) -> None or float:
    if is_bundled:
        return f"@{stop_loss_price}"
    return None
