# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import decimal as decimal
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.position_size_settings as size_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.utilities as utilities
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data.open_positions as open_positions
import octobot_trading.modes.script_keywords.basic_keywords.account_balance as account_balance
import octobot_trading.enums as trading_enums


class ManagedOrderPositionSizing(utilities.ManagedOrderUtilities):
    def __init__(self):
        super().__init__()
        self.market_fee = 0
        self.limit_fee = 0
        self.entry_fees = 0
        self.exit_fee = 0
        self.position_size = 0
        self.current_open_risk = 0
        self.max_position_size = 0
        self.max_buying_power = 0
        self.place_entries = False

        self.sl_price = 0
        self.sl_in_p = 0
        self.sl_indicator_value = 0
        self.expected_entry_price = 0
        self.entry_price = 0
        self.current_price_val = 0

    async def set_managed_position_size(
        self, ctx, entry_price, entry_order_type, stop_loss_in_percent
    ):
        # position size
        self.limit_fee, self.market_fee = get_fees(ctx)

        # tmp
        self.deci_limit_fee = decimal.Decimal(str(self.limit_fee))
        self.deci_market_fee = decimal.Decimal(str(self.market_fee))
        # position size based on dollar/reference market risk
        if (
            self.managed_orders_settings.position_size_type
            == size_settings.ManagedOrderSettingsPositionSizeTypes.QUANTITY_RISK_OF_ACCOUNT_DESCRIPTION
        ):
            (
                self.position_size,
                self.max_position_size,
                self.current_open_risk,
            ) = get_position_size_based_ref_market_quantity_risk(
                ctx,
                entry_order_type=entry_order_type,
                stop_loss_percent=stop_loss_in_percent,
                risk_in_ref_market_quantity=self.managed_orders_settings.risk_in_d,
                total_risk_in_ref_market_quantity=self.managed_orders_settings.total_risk_in_d,
                entry_price=entry_price,
                limit_fees=self.limit_fee,
                market_fees=self.market_fee,
            )

        # position size based risk per trade in percent
        elif (
            self.managed_orders_settings.position_size_type
            == size_settings.ManagedOrderSettingsPositionSizeTypes.PERCENT_RISK_OF_ACCOUNT_DESCRIPTION
        ):
            current_total_acc_balance = float(
                await account_balance.total_account_balance(ctx)
            )
            (
                self.position_size,
                self.max_position_size,
                self.current_open_risk,
            ) = await get_position_size_based_risk_percent(
                ctx,
                entry_order_type=entry_order_type,
                stop_loss_percent=stop_loss_in_percent,
                risk_in_percent=self.managed_orders_settings.risk_in_p,
                total_risk_in_percent=self.managed_orders_settings.total_risk_in_p,
                current_total_acc_balance=current_total_acc_balance,
                limit_fees=self.limit_fee,
                market_fees=self.market_fee,
            )

        # position size based on percent of total account balance
        elif (
            self.managed_orders_settings.position_size_type
            == size_settings.ManagedOrderSettingsPositionSizeTypes.PERCENT_OF_ACCOUNT_DESCRIPTION
        ):
            current_total_acc_balance = float(
                await account_balance.total_account_balance(ctx)
            )
            (
                self.position_size,
                self.max_position_size,
            ) = get_position_size_based_on_account(
                ctx,
                self.trading_side,
                self.managed_orders_settings.risk_in_p,
                self.managed_orders_settings.total_risk_in_p,
                current_total_acc_balance,
            )

        (
            self.max_position_size,
            self.max_buying_power,
            self.position_size,
        ) = await adapt_sizes_to_limits(
            ctx,
            self.position_size,
            self.max_buying_power,
            self.max_position_size,
            self.entry_side,
        )
        if self.position_size == 0:
            ctx.logger.warning(
                "Managed order cant open a new position, "
                "the digits adapted price is 0. Make sure the position size is at "
                f"least the minimum size required by the exchange for {ctx.symbol}"
            )
            return
        if self.position_size < 0:
            ctx.logger.info(
                "Managed order cant open a new position, "
                "maximum position size is reached"
            )
            return
        self.place_entries = True


def get_fees(ctx):
    fees = exchange_public_data.symbol_fees(ctx)
    fallback_fees = fees.get("fee", 0)
    limit_fee = float(fallback_fees if fees["maker"] is None else fees["maker"]) * 100
    market_fee = float(fallback_fees if fees["taker"] is None else fees["taker"]) * 100
    return limit_fee, market_fee


async def adapt_sizes_to_limits(
    ctx, position_size, max_buying_power, max_position_size, entry_side
):
    max_position_size = float(
        exchange_public_data.get_digits_adapted_amount(
            ctx, decimal.Decimal(max_position_size)
        )
    )

    max_buying_power = float(
        exchange_public_data.get_digits_adapted_amount(
            ctx,
            await account_balance.available_account_balance(
                ctx, side=entry_side, reduce_only=False
            ),
        )
    )

    # check if enough balance for requested size and cut if necessary
    if max_buying_power < position_size:
        position_size = max_buying_power

    # cut the position size so that it aligns with target risk
    if position_size > max_position_size:
        position_size = max_position_size

    position_size = float(
        exchange_public_data.get_digits_adapted_amount(
            ctx, decimal.Decimal(position_size)
        )
    )
    return max_position_size, max_buying_power, position_size


async def get_current_open_risk(ctx, market_fee):
    current_average_long_entry = float(
        await open_positions.average_open_pos_entry(ctx, side="long")
    )
    current_average_short_entry = float(
        await open_positions.average_open_pos_entry(ctx, side="short")
    )
    current_open_orders = (
        ctx.exchange_manager.exchange_personal_data.orders_manager.orders
    )
    current_open_risk = 0
    for order in current_open_orders:
        if (
            current_open_orders[order].order_type
            == trading_enums.TraderOrderType.STOP_LOSS
        ):
            if current_open_orders[order].side == trading_enums.TradeOrderSide.SELL:
                stop_loss_distance = current_average_long_entry - float(
                    current_open_orders[order].origin_price
                )
            else:
                stop_loss_distance = (
                    float(current_open_orders[order].origin_price)
                    - current_average_short_entry
                )
            current_open_risk += ((market_fee) / 100) * float(
                current_open_orders[order].origin_quantity
            ) + (
                float(current_open_orders[order].origin_quantity)
                * stop_loss_distance
                / float(current_open_orders[order].origin_price)
            )
    return current_open_risk


async def get_position_size_based_ref_market_quantity_risk(
    ctx,
    entry_order_type: str,
    stop_loss_percent: float,
    risk_in_ref_market_quantity: float,
    total_risk_in_ref_market_quantity: float,
    entry_price: float,
    limit_fees: float,
    market_fees: float,
):
    if entry_order_type == "market":
        position_size = (
            (risk_in_ref_market_quantity / entry_price)
            / (stop_loss_percent + (market_fees + market_fees))
        ) / 0.01
    else:
        position_size = (
            (risk_in_ref_market_quantity / entry_price)
            / (stop_loss_percent + (limit_fees + market_fees))
        ) / 0.01
    current_open_risk = await get_current_open_risk(ctx, market_fees)

    max_position_size = (
        ((total_risk_in_ref_market_quantity / entry_price) - current_open_risk)
        / (stop_loss_percent + (2 * market_fees))
    ) / 0.01
    return position_size, max_position_size, current_open_risk


async def get_position_size_based_risk_percent(
    ctx,
    entry_order_type: str,
    stop_loss_percent: float,
    risk_in_percent: float,
    total_risk_in_percent: float,
    current_total_acc_balance: float,
    limit_fees: float,
    market_fees: float,
):
    risk_in_d = (risk_in_percent / 100) * current_total_acc_balance
    if entry_order_type == "market":
        position_size = (risk_in_d / (stop_loss_percent + (2 * market_fees))) / 0.01
    else:
        position_size = (
            risk_in_d / (stop_loss_percent + limit_fees + market_fees)
        ) / 0.01
    current_open_risk = await get_current_open_risk(ctx, market_fees)

    total_risk_in_d = (
        total_risk_in_percent / 100
    ) * current_total_acc_balance - current_open_risk
    max_position_size = (
        total_risk_in_d / (stop_loss_percent + (2 * market_fees))
    ) / 0.01
    return position_size, max_position_size, current_open_risk


def get_position_size_based_on_account(
    ctx,
    trading_side,
    stop_loss_percent: float,
    stop_loss_total_percent: float,
    current_total_acc_balance: float,
) -> tuple:
    # position is the same for limit and market entry
    position_size = (stop_loss_percent / 100) * current_total_acc_balance
    current_open_position_size = open_positions.open_position_size(ctx, side="both")
    if trading_side == trading_enums.PositionSide.SHORT.value:
        current_open_position_size *= -1
    max_position_size = (stop_loss_total_percent / 100) * current_total_acc_balance
    return position_size, max_position_size
