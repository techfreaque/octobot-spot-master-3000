# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import typing
import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.orders.scaled_orders as scaled_orders
import octobot_trading.modes.script_keywords.context_management as context_management


class ManagedOrderSettingsEntryTypes:
    SINGLE_MARKET_IN = "market_in"
    SINGLE_LIMIT_IN = "limit_in"
    SINGLE_TRY_LIMIT_IN = "try_limit_in"
    SCALED_OVER_TIME = "time_grid_orders"
    SCALED_DYNAMIC = "scaled_entry"
    SCALED_STATIC = "grid_entry"

    SINGLE_MARKET_IN_DESCRIPTION = "Single market in"
    SINGLE_LIMIT_IN_DESCRIPTION = "Single limit in"
    SINGLE_TRY_LIMIT_IN_DESCRIPTION = "Single try limit in"
    SCALED_OVER_TIME_DESCRIPTION = "Scale entry orders over time"
    SCALED_DYNAMIC_DESCRIPTION = "Scale limit orders over a dynamic price range"
    SCALED_STATIC_DESCRIPTION = "Scale limit orders over a static price range"

    KEY_TO_DESCRIPTIONS = {
        SINGLE_MARKET_IN: SINGLE_MARKET_IN_DESCRIPTION,
        SINGLE_LIMIT_IN: SINGLE_LIMIT_IN_DESCRIPTION,
        SINGLE_TRY_LIMIT_IN: SINGLE_TRY_LIMIT_IN_DESCRIPTION,
        SCALED_OVER_TIME: SCALED_OVER_TIME_DESCRIPTION,
        SCALED_DYNAMIC_DESCRIPTION: SCALED_DYNAMIC_DESCRIPTION,
        SCALED_STATIC: SCALED_STATIC_DESCRIPTION,
    }
    DESCRIPTIONS = [
        SINGLE_MARKET_IN_DESCRIPTION,
        SINGLE_LIMIT_IN_DESCRIPTION,
        # SINGLE_TRY_LIMIT_IN_DESCRIPTION,
        # SCALED_OVER_TIME_DESCRIPTION,
        SCALED_DYNAMIC_DESCRIPTION,
        SCALED_STATIC_DESCRIPTION,
    ]


class ManagedOrderSettingsEntry:
    def __init__(self) -> None:
        self.ctx: context_management.Context = None

        self.entry_path: str = None
        self.entry_setting_name: str = None

        self.entry_type: str = None
        self.limit_offset: float = None
        self.slippage_limit: float = None
        self.market_in_if_limit_fails: bool = None

        self.entry_scaled_min: float = None
        self.entry_scaled_max: float = None
        self.entry_scaled_order_count: int = None
        self.scaled_entry_price_distribution_type: str = None
        self.scaled_entry_price_growth_factor: float = None
        self.scaled_entry_value_distribution_type: str = None
        self.scaled_entry_value_growth_factor: float = None
        self.entry_scaled_min: float = None
        self.entry_scaled_max: float = None

        self.entry_multi_grid_mode: bool = None
        self.amount_of_entry_grids: int = None
        self.entry_grids: typing.Dict[ManagedOrderEntryGrid] = None
        
        self.user_input_name_prefix: str = None

    async def initialize_entry_settings(self):
        # entry type
        self.entry_type = await basic_keywords.user_input(
            self.ctx,
            self.user_input_name_prefix+"entry_type",
            "options",
            ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION,
            title="entry type",
            options=ManagedOrderSettingsEntryTypes.DESCRIPTIONS,
            path=self.entry_path,
            parent_input_name=self.entry_setting_name,
        )
        # entry: limit in
        if (
            self.entry_type
            == ManagedOrderSettingsEntryTypes.SINGLE_LIMIT_IN_DESCRIPTION
        ):
            self.limit_offset = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"limit_entry_offset_in_%",
                "float",
                0.2,
                title="limit entry offset in %",
                min_val=0,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )

        # entry: try limit in
        if (
            self.entry_type
            == ManagedOrderSettingsEntryTypes.SINGLE_TRY_LIMIT_IN_DESCRIPTION
        ):
            self.slippage_limit = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"slippage_limit",
                "float",
                40,
                title="Slippage Limit: can be % or price",
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            self.market_in_if_limit_fails = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"try_to_limit_in",
                "boolean",
                True,
                title="try to limit in",
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )

            # self.entry_scaled_order_count = await basic_keywords.user_input(
            #     self.ctx,
            #     "amount of entry orders",
            #     "int",
            #     10,
            #     min_val=2,
            #     path=self.entry_path,
            #     parent_input_name=self.entry_setting_name,
            # )

        if (
            self.entry_type == ManagedOrderSettingsEntryTypes.SCALED_STATIC_DESCRIPTION
            or self.entry_type
            == ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION
        ):
            grid_type_name = (
                "dynamic"
                if self.entry_type
                == ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION
                else "static"
            )
            self.entry_multi_grid_mode = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+f"entry_{grid_type_name}_multi_grid_mode",
                "boolean",
                False,
                title="Use multiple grids",
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            if self.entry_multi_grid_mode:
                self.amount_of_entry_grids = await basic_keywords.user_input(
                    self.ctx,
                    self.user_input_name_prefix+f"amount_of_{grid_type_name}_entry_grids",
                    "int",
                    2,
                    title="How many grids?",
                    min_val=1,
                    path=self.entry_path,
                    parent_input_name=self.entry_setting_name,
                )
            else:
                self.amount_of_entry_grids = 1
            self.entry_grids = {}
            for grid_id in range(1, self.amount_of_entry_grids + 1):
                grid_name = self.user_input_name_prefix+f"{grid_type_name}_entry_grid_{grid_id}"
                grid_suffix = self.user_input_name_prefix+grid_name + "_"
                if self.amount_of_entry_grids != 1:
                    title = f"Grid {grid_id}"
                    await basic_keywords.user_input(
                        self.ctx,
                        grid_name,
                        "object",
                        None,
                        title=title,
                        path=self.entry_path,
                        parent_input_name=self.entry_setting_name,
                    )
                    if self.entry_path:
                        grid_input_path = self.entry_path + "/" + title
                        parent_input_name = None
                    else:
                        grid_input_path = None
                        parent_input_name = grid_name

                    value_percent = await basic_keywords.user_input(
                        self.ctx,
                        grid_suffix + "position_size_percent",
                        "float",
                        50,
                        min_val=0,
                        max_val=100,
                        title="Percent of total position value to use for this grid",
                        path=grid_input_path,
                        parent_input_name=parent_input_name,
                    )
                else:
                    if self.entry_path:
                        grid_input_path = self.entry_path
                        parent_input_name = None
                    else:
                        grid_input_path = None
                        parent_input_name = self.entry_setting_name
                    value_percent = 100
                price_distribution_type = await basic_keywords.user_input(
                    self.ctx,
                    grid_suffix + "price_distribution_type",
                    "options",
                    scaled_orders.ScaledOrderPriceDistributionTypes.LINEAR_GROWTH,
                    title="Grid price distribution type",
                    options=scaled_orders.ScaledOrderPriceDistributionTypes.all_types,
                    path=grid_input_path,
                    parent_input_name=parent_input_name,
                )
                price_growth_factor = None
                if price_distribution_type in (
                    scaled_orders.ScaledOrderPriceDistributionTypes.LINEAR_GROWTH,
                    scaled_orders.ScaledOrderPriceDistributionTypes.EXPONENTIAL,
                ):
                    price_growth_factor = await basic_keywords.user_input(
                        self.ctx,
                        grid_suffix + "price_growth_rate",
                        "float",
                        2,
                        title="Price scaling growth rate",
                        min_val=0.0000001,
                        path=grid_input_path,
                        max_val=100,
                        parent_input_name=parent_input_name,
                    )
                order_count = await basic_keywords.user_input(
                    self.ctx,
                    grid_suffix + "amount_of_orders",
                    "int",
                    10,
                    title="amount of orders",
                    min_val=2,
                    path=grid_input_path,
                    parent_input_name=parent_input_name,
                )
                value_distribution_type = await basic_keywords.user_input(
                    self.ctx,
                    grid_suffix + "value_distribution_type",
                    "options",
                    scaled_orders.ScaledOrderValueDistributionTypes.LINEAR_GROWTH,
                    title="Value distribution type",
                    options=scaled_orders.ScaledOrderValueDistributionTypes.all_types,
                    path=grid_input_path,
                    parent_input_name=parent_input_name,
                )
                value_growth_factor = None
                if value_distribution_type in (
                    scaled_orders.ScaledOrderValueDistributionTypes.LINEAR_GROWTH,
                    scaled_orders.ScaledOrderValueDistributionTypes.EXPONENTIAL,
                ):
                    value_growth_factor = await basic_keywords.user_input(
                        self.ctx,
                        grid_suffix + "value_growth_rate",
                        "float",
                        2,
                        title="Value scaling growth rate",
                        min_val=0.0000001,
                        path=grid_input_path,
                        max_val=100,
                        parent_input_name=parent_input_name,
                    )
                if (
                    self.entry_type
                    == ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION
                ):
                    from_level = await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"scale_limit_orders_from",
                        "float",
                        1,
                        title="scale limit orders from: (measured in %) ",
                        min_val=0,
                        path=self.entry_path,
                        parent_input_name=self.entry_setting_name,
                    )
                    to_level = await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"scale_limit_orders_to",
                        "float",
                        2,
                        title="scale limit orders to: (measured in %)",
                        min_val=0,
                        path=self.entry_path,
                        parent_input_name=self.entry_setting_name,
                    )
                else:
                    from_level = await basic_keywords.user_input(
                        self.ctx,
                        grid_suffix + "from_price",
                        "float",
                        None,
                        title="Scale limit orders from price",
                        min_val=0,
                        path=grid_input_path,
                        parent_input_name=parent_input_name,
                    )
                    to_level = await basic_keywords.user_input(
                        self.ctx,
                        grid_suffix + "to_price",
                        "float",
                        None,
                        title="Scale limit orders to price",
                        min_val=0,
                        path=grid_input_path,
                        parent_input_name=parent_input_name,
                    )

                self.entry_grids[grid_id] = ManagedOrderEntryGrid(
                    grid_id=grid_id,
                    price_distribution_type=price_distribution_type,
                    price_growth_factor=price_growth_factor,
                    order_count=order_count,
                    value_distribution_type=value_distribution_type,
                    value_growth_factor=value_growth_factor,
                    from_level=from_level,
                    to_level=to_level,
                    value_percent=value_percent,
                )


class ManagedOrderEntryGrid:
    def __init__(
        self,
        grid_id,
        price_distribution_type,
        price_growth_factor,
        order_count,
        value_distribution_type,
        value_growth_factor,
        from_level,
        to_level,
        value_percent,
    ):
        self.grid_id = grid_id
        self.price_distribution_type = price_distribution_type
        self.price_growth_factor = price_growth_factor
        self.order_count = order_count
        self.value_distribution_type = value_distribution_type
        self.value_growth_factor = value_growth_factor
        self.from_level = from_level
        self.to_level = to_level
        self.value_percent = value_percent
