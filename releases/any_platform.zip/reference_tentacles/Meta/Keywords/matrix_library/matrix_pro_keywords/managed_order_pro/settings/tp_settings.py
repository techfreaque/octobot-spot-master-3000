# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import decimal
import octobot_trading.modes.script_keywords.context_management as context_management
import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
from tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.entry_settings import (
    ManagedOrderSettingsEntryTypes,
)
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.position_size_settings as size_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings as sl_settings


class ManagedOrderSettingsTPTypes:
    NO_TP = "no_tp"
    SINGLE_RISK_REWARD = "SINGLE_RISK_REWARD"
    SINGLE_PERCENT = "SINGLE_PERCENT"
    SINGLE_STATIC = "SINGLE_STATIC"
    SCALED_RISK_REWARD = "SCALED_RISK_REWARD"
    SCALED_PERCENT = "SCALED_PERCENT"
    SCALED_STATIC = "SCALED_STATIC"

    NO_TP_DESCRIPTION = "dont use managed Take Profit"
    SINGLE_RISK_REWARD_DESCRIPTION = "take profit based on risk reward"
    SINGLE_PERCENT_DESCRIPTION = "take profit based on fixed percent"
    SINGLE_STATIC_DESCRIPTION = "take profit based on static price"
    SCALED_RISK_REWARD_DESCRIPTION = "scaled take profit based on risk reward"
    SCALED_PERCENT_DESCRIPTION = "scaled take profit based on percent"
    SCALED_STATIC_DESCRIPTION = "spread limit exits based on a dynamic or static range"

    KEY_TO_DESCRIPTIONS = {
        NO_TP: NO_TP_DESCRIPTION,
        SINGLE_RISK_REWARD: SINGLE_RISK_REWARD_DESCRIPTION,
        SINGLE_PERCENT: SINGLE_PERCENT_DESCRIPTION,
        SINGLE_STATIC: SINGLE_STATIC_DESCRIPTION,
        SCALED_RISK_REWARD: SCALED_RISK_REWARD_DESCRIPTION,
        SCALED_PERCENT: SCALED_PERCENT_DESCRIPTION,
        SCALED_STATIC: SCALED_STATIC_DESCRIPTION,
    }
    DESCRIPTIONS = [
        NO_TP_DESCRIPTION,
        SINGLE_RISK_REWARD_DESCRIPTION,
        SINGLE_PERCENT_DESCRIPTION,
        SINGLE_STATIC_DESCRIPTION,
        # SCALED_RISK_REWARD_DESCRIPTION,
        # SCALED_PERCENT_DESCRIPTION,
        # SCALED_STATIC_DESCRIPTION,
    ]


class ManagedOrderSettingsTP(size_settings.ManagedOrderSettingsPositionSize):
    def __init__(self) -> None:
        super().__init__()
        self.ctx: context_management.Context = None

        self.tp_path: str = None
        self.tp_setting_name: str = None

        self.tp_type: str = None
        self.tp_rr: decimal.Decimal = None
        self.tp_in_p: decimal.Decimal = None
        self.tp_in_d: decimal.Decimal = None
        self.rr_tp_min: decimal.Decimal = None
        self.rr_tp_max: decimal.Decimal = None
        self.rr_tp_order_count: int = None
        self.p_tp_order_count: int = None
        self.p_tp_min: decimal.Decimal = None
        self.p_tp_max: decimal.Decimal = None
        self.position_mode: str = None
        self.use_bundled_tp_orders: bool = None
        
        self.user_input_name_prefix: str = None

    async def initialize_tp_settings(self):
        self.use_bundled_tp_orders = True # await basic_keywords.user_input(
        #     self.ctx,
        #     "Bundle take profit order with entry order",
        #     "boolean",
        #     False,
        #     path=self.tp_path,
        #     parent_input_name=self.tp_setting_name,
        #     other_schema_values={
        #         "description": "When this option is enabled the TP will only get "
        #         "placed once the entry got filled (OctoBot must be running). "
        #         "Only on bybit futures it will already place the TP with the entry "
        #         "and OctoBot doesnt need to run for the SL"
        #     },
        #     show_in_optimizer=False,
        #     show_in_summary=False,
        # )
        if self.sl_type == sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION:
            tp_type_def_val = ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION
            if self.use_bundled_tp_orders:
                if self.entry_type in (
                    ManagedOrderSettingsEntryTypes.SINGLE_LIMIT_IN_DESCRIPTION,
                    ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION,
                ):
                    tp_type_optinions = [
                        ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION,
                    ]
                else:
                    tp_type_optinions = [
                        ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION,
                    ]
            else:
                tp_type_optinions = [
                    ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION,
                    # ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION,
                    ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION,
                    # ManagedOrderSettingsTPTypes.SCALED_PERCENT_DESCRIPTION,
                    # ManagedOrderSettingsTPTypes.SCALED_STATIC_DESCRIPTION,
                ]
        else:
            tp_type_def_val = ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION
            if self.use_bundled_tp_orders:
                if self.entry_type in (
                    ManagedOrderSettingsEntryTypes.SINGLE_LIMIT_IN_DESCRIPTION,
                    ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION,
                ):
                    tp_type_optinions = [
                        ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION,
                    ]
                else:
                    tp_type_optinions = [
                        ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION,
                    ]
            else:
                if self.entry_type in (
                    ManagedOrderSettingsEntryTypes.SINGLE_LIMIT_IN_DESCRIPTION,
                    ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION,
                ):
                    tp_type_optinions = [
                        ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION,
                    ]
                else:
                    tp_type_optinions = [
                        ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION,
                        ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION,
                    ]

        # TP
        self.tp_type = await basic_keywords.user_input(
            self.ctx,
            self.user_input_name_prefix+"take_profit_type",
            "options",
            tp_type_def_val,
            options=tp_type_optinions,
            title="Take profit type",
            path=self.tp_path,
            parent_input_name=self.tp_setting_name,
        )
        # TP based on risk reward
        if self.tp_type == ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION:
            self.tp_rr = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"tp_risk_reward_target",
                        "float",
                        2,
                        min_val=0,
                        title="TP Risk Reward target",
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )

        # TP based on percent
        elif self.tp_type == ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION:
            self.tp_in_p = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"take_profit_in_percent",
                        "float",
                        2,
                        title="Take profit in %",
                        min_val=0,
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )

        # single TP based on static price
        elif self.tp_type == ManagedOrderSettingsTPTypes.SINGLE_STATIC_DESCRIPTION:
            self.tp_in_d = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"take_profit_static_price",
                        "float",
                        None,
                        title="Take profit static price",
                        min_val=0,
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )

        # scaled TP based on risk reward
        elif (
            self.tp_type == ManagedOrderSettingsTPTypes.SCALED_RISK_REWARD_DESCRIPTION
            and not self.use_bundled_tp_orders
        ):
            self.rr_tp_min = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"take_profit_min_risk_reward_target",
                        "float",
                        2,
                        min_val=0,
                        title="take profit min risk reward target",
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )
            self.rr_tp_max = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"take_profit_max_risk_reward_target",
                        "float",
                        10,
                        min_val=0,
                        title="take profit max risk reward target",
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )
            self.rr_tp_order_count = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"take_profit_order_count",
                "int",
                10,
                min_val=2,
                title="take profit order count",
                path=self.tp_path,
                parent_input_name=self.tp_setting_name,
            )

        # scaled TP based on percent
        elif (
            self.tp_type == ManagedOrderSettingsTPTypes.SCALED_PERCENT_DESCRIPTION
            and not self.use_bundled_tp_orders
        ):
            self.p_tp_min = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"scale_take_profit_from_%",
                        "float",
                        1,
                        min_val=0,
                        title="scale take profit from: (measured in %) ",
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )
            self.p_tp_max = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"scale_take_profit_to_%",
                        "float",
                        50,
                        min_val=0,
                        title="scale take profit to: (measured in %",
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )
            self.p_tp_order_count = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"take_profit_order_count",
                "int",
                10,
                min_val=2,
                title="take profit order count",
                path=self.tp_path,
                parent_input_name=self.tp_setting_name,
            )

        # grid sell based on percent
        elif (
            self.tp_type == ManagedOrderSettingsTPTypes.SCALED_STATIC_DESCRIPTION
            and not not self.use_bundled_tp_orders
        ):
            self.position_mode = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"position_mode",
                "options",
                "long only",
                options=["long only", "short only", "both"],
                title="Position Mode",
                path=self.tp_path,
                parent_input_name=self.tp_setting_name,
                other_schema_values={
                    "description": "When both: it will reach the maximum short "
                    "size at the top of the range, and the max long position at the"
                    " bottom. - "
                    "When short only: it will reach the maximum short size at the"
                    " top of the range, and will be in no position at the top"
                    " bottom. - "
                    "When long only: the max size is reached at the bottom and yo"
                },
            )
            self.p_tp_min = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"scale_sell_orders_from_price",
                        "float",
                        1,
                        min_val=0,
                        title="scale sell orders from price",
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )
            self.p_tp_max = decimal.Decimal(
                str(
                    await basic_keywords.user_input(
                        self.ctx,
                        self.user_input_name_prefix+"scale_sell_orders_to_price",
                        "float",
                        50,
                        min_val=0,
                        title="scale sell orders to price",
                        path=self.tp_path,
                        parent_input_name=self.tp_setting_name,
                    )
                )
            )
            self.p_tp_order_count = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"take_profit_order_count",
                "int",
                10,
                min_val=2,
                title="take profit order count",
                path=self.tp_path,
                parent_input_name=self.tp_setting_name,
            )
