# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import decimal as decimal
import typing
from tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings import (
    sl_settings,
)
from tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings import (
    ManagedOrderSettingsSLTrailTypes,
    ManagedOrderSettingsSLTypes,
)
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.stop_losses.trailing_types as trailing_types
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
import tentacles.Meta.Keywords.scripting_library.orders.editing as editing
import tentacles.Meta.Keywords.scripting_library.orders.open_orders as open_orders
import tentacles.Meta.Keywords.scripting_library.orders.waiting as waiting
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.stop_losses.stop_loss_types as stop_loss_types
import octobot_trading.enums as trading_enums
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data.open_positions as open_positions


async def get_manged_order_stop_loss(
    ctx,
    managed_orders_settings,
    trading_side,
    entry_price=None,
    sl_indicator_value=None,
) -> typing.Tuple[float, float]:
    sl_price: float = None
    sl_in_p: float = None
    entry_price = entry_price or float(
        await exchange_public_data.current_live_price(ctx)
    )
    # SL based on low/high
    if (
        managed_orders_settings.sl_type
        == ManagedOrderSettingsSLTypes.AT_LOW_HIGH_DESCRIPTION
    ):
        sl_in_p, sl_price = await stop_loss_types.get_stop_loss_based_on_low_high(
            ctx, managed_orders_settings, trading_side, entry_price
        )
    # SL based on percent
    elif (
        managed_orders_settings.sl_type
        == ManagedOrderSettingsSLTypes.BASED_ON_PERCENT_DESCRIPTION
    ):
        sl_in_p, sl_price = stop_loss_types.get_stop_loss_based_on_percent(
            managed_orders_settings, trading_side, entry_price
        )
    # SL based on indicator
    elif (
        managed_orders_settings.sl_type
        == ManagedOrderSettingsSLTypes.BASED_ON_INDICATOR_DESCRIPTION
    ):
        sl_in_p, sl_price = stop_loss_types.get_stop_loss_based_on_indicator(
            managed_orders_settings=managed_orders_settings,
            trading_side=trading_side,
            current_price_val=entry_price,
            sl_indicator_value=sl_indicator_value,
        )
    # SL based on static price
    elif (
        managed_orders_settings.sl_type
        == ManagedOrderSettingsSLTypes.BASED_ON_STATIC_PRICE_DESCRIPTION
    ):
        sl_in_p, sl_price = stop_loss_types.get_stop_loss_based_on_static_price(
            managed_orders_settings, trading_side, entry_price
        )

    # SL based on ATR
    elif (
        managed_orders_settings.sl_type
        == ManagedOrderSettingsSLTypes.BASED_ON_ATR_DESCRIPTION
    ):
        sl_in_p, sl_price = await stop_loss_types.get_stop_loss_based_on_atr(
            ctx, managed_orders_settings, trading_side, entry_price
        )
    return (
        float(
            exchange_public_data.get_digits_adapted_price(
                ctx, decimal.Decimal(sl_price)
            )
        ),
        sl_in_p,
    )


async def trail_stop_losses(
    ctx,
    managed_orders_settings,
    sl_indicator_value=None,
    sl_trailing_indicator_value=None,
):
    """
    :param managed_orders_settings:
    :param ctx:
    :param sl_indicator_value: When set to SL based on indicator and trailing stop based on SL settings
            a sl_indicator_value for the current candle must be provided
    :param sl_trailing_indicator_value: When set to trailing SL based on indicator
            a sl_indicator_value for the current candle must be provided
    :return:
    """
    if (
        not managed_orders_settings.sl_trail_type
        == ManagedOrderSettingsSLTrailTypes.DONT_TRAIL_DESCRIPTION
    ):
        _open_orders = open_orders.get_open_orders(ctx)
        if _open_orders:
            current_price = float(await exchange_public_data.current_candle_price(ctx))
            av_entry = None
            fees = None
            for order in _open_orders:
                if order.tag and order.tag.startswith(managed_orders_settings.order_tag_prefix):
                    new_sl_price = None
                    managed_orders_settings.trading_side = (
                        trading_enums.PositionSide.LONG.value
                        if order.side is trading_enums.TradeOrderSide.SELL
                        else trading_enums.PositionSide.SHORT.value
                    )
                    if (
                        order.exchange_order_type is trading_enums.TradeOrderType.STOP_LOSS
                        and order.status.value == "open"
                    ):
                        # todo get real entry for each order
                        av_entry = av_entry or float(
                            await open_positions.average_open_pos_entry(
                                ctx, side=managed_orders_settings.trading_side
                            )
                        )
                        if check_if_can_start_trailing(
                            managed_orders_settings, av_entry, current_price
                        ):
                            if (
                                managed_orders_settings.sl_trail_type
                                == ManagedOrderSettingsSLTrailTypes.BREAK_EVEN_DESCRIPTION
                            ):
                                new_sl_price = await trailing_types.trail_to_break_even(
                                    ctx, managed_orders_settings, av_entry, fees
                                )
                            elif (
                                managed_orders_settings.sl_trail_type
                                == ManagedOrderSettingsSLTrailTypes.TRAILING_DESCRIPTION
                            ):
                                new_sl_price = (
                                    await trailing_types.trail_to_stop_loss_settings(
                                        ctx, managed_orders_settings, sl_indicator_value
                                    )
                                )
                            elif (
                                managed_orders_settings.sl_trail_type
                                == ManagedOrderSettingsSLTrailTypes.TRAILING_INDICATOR_DESCRIPTION
                            ):
                                new_sl_price = await trailing_types.trail_to_indicator(
                                    ctx,
                                    managed_orders_settings,
                                    sl_trailing_indicator_value,
                                )
                            if new_sl_price := adapt_sl_price_and_check_if_can_continue_trailing(
                                managed_orders_settings, order, new_sl_price, av_entry
                            ):
                                try:
                                    await editing.edit_order(
                                        ctx, order, edited_stop_price=new_sl_price
                                    )
                                except Exception as e:
                                    ctx.logger.error(
                                        f"Error editing trailing stop loss. Error: {e}"
                                    )


def trim_sl_long_price(sl_price, current_price, sl_max_p, sl_min_p):
    sl_in_p = (current_price - sl_price) / current_price * 100
    if sl_in_p > sl_max_p:
        return sl_max_p, (1 - (sl_max_p / 100)) * current_price
    elif sl_in_p < sl_min_p:
        return sl_min_p, (1 - (sl_min_p / 100)) * current_price
    return sl_in_p, sl_price


def trim_sl_short_price(sl_price, current_price, sl_max_p, sl_min_p):
    sl_in_p = (current_price - sl_price) / current_price * 100
    sl_max_p *= -1
    sl_min_p *= -1
    if sl_in_p < sl_max_p:
        return sl_max_p, (1 + (-sl_max_p / 100)) * current_price
    elif sl_in_p > sl_min_p:
        return sl_min_p, (1 + (-sl_min_p / 100)) * current_price
    return sl_in_p, sl_price


def adapt_sl_price_and_check_if_can_continue_trailing(
    managed_orders_settings, order, new_sl_price, av_entry
):
    if order.origin_price < new_sl_price:
        if av_entry < new_sl_price:
            return new_sl_price
        elif managed_orders_settings.sl_trail_start_only_if_above_entry:
            return None
        else:
            return new_sl_price
    return None


def check_if_can_start_trailing(managed_orders_settings, av_entry, current_price):
    if not managed_orders_settings.sl_trail_start_only_in_profit:
        return True
    elif managed_orders_settings.trading_side == trading_enums.PositionSide.LONG.value:
        trail_start_price = (
            1 + (managed_orders_settings.sl_trail_start / 100)
        ) * av_entry
        if current_price >= trail_start_price:
            return True
    else:
        trail_start_price = (
            1 - (managed_orders_settings.sl_trail_start / 100)
        ) * av_entry
        if current_price <= trail_start_price:
            return True


async def adjust_managed_stop_loss(ctx, managed_orders_settings, managed_order_data):
    # edit stop loss to accurate values in real trading

    # wait for market order to be filled
    await waiting.wait_for_orders_close(
        ctx, managed_order_data.created_orders, timeout=60
    )

    # get up-to-date entry filled price and size
    managed_order_data.entry_price = float(
        managed_order_data.created_orders[0].filled_price
    )
    managed_order_data.exit_amount = float(
        managed_order_data.created_orders[0].filled_quantity
    )

    # # wait for initial stop loss to be placed
    init_stop_order = await waiting.wait_for_stop_loss_open(
        ctx,
        managed_order_data.exit_order_tag,
        managed_order_data.order_group,
        timeout=45,
    )

    (
        new_sl_price,
        managed_order_data.sl_in_p,
    ) = await get_manged_order_stop_loss(
        ctx,
        managed_orders_settings,
        managed_order_data.trading_side,
        entry_price=managed_order_data.entry_price,
        sl_indicator_value=managed_order_data.sl_indicator_value,
    )
    # # update stop loss on exchange
    new_sl_price = exchange_public_data.get_digits_adapted_price(
        ctx, decimal.Decimal(new_sl_price)
    )
    if init_stop_order:
        if init_stop_order.origin_price != new_sl_price:
            try:
                await editing.edit_order(
                    ctx, order=init_stop_order, edited_stop_price=new_sl_price
                )
                managed_order_data.sl_in_d = float(new_sl_price)
            except Exception as e:  # fails if we try to set an SL above the current price
                # retry one more time before giving up editing the order
                try:
                    await editing.edit_order(
                        ctx, order=init_stop_order, edited_stop_price=new_sl_price
                    )
                    managed_order_data.sl_in_d = float(new_sl_price)
                except Exception as e:  # catch all errors to continue placing take profits
                    ctx.logger.error(
                        "Managed order: adjusting stop loss failed. This happened probably"
                        f" because the adjusted stop loss would have been trigger instantly error: {e}"
                    )

    else:
        ctx.logger.error(
            "Managed Order: failed to get stop loss from exchange. "
            "Could not adjust stop loss based on filled price"
        )
        managed_order_data.enabled_order_group = False
    return managed_order_data
