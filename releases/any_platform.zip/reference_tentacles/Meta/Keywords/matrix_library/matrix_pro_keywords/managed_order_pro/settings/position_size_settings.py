# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings as sl_settings
import octobot_trading.modes.script_keywords.context_management as context_management


class ManagedOrderSettingsPositionSizeTypes:
    QUANTITY_RISK_OF_ACCOUNT = "quantity_risk_of_account"
    PERCENT_RISK_OF_ACCOUNT = "percent_risk_of_account"
    PERCENT_OF_ACCOUNT = "percent_of_account"

    QUANTITY_RISK_OF_ACCOUNT_DESCRIPTION = (
        "Position size based on quantity risk (for example 0.1 BTC)"
    )
    PERCENT_RISK_OF_ACCOUNT_DESCRIPTION = (
        "Position size based on % risk of total account"
    )
    PERCENT_OF_ACCOUNT_DESCRIPTION = "Position size based on % of account size"

    KEY_TO_DESCRIPTIONS = {
        QUANTITY_RISK_OF_ACCOUNT: QUANTITY_RISK_OF_ACCOUNT_DESCRIPTION,
        PERCENT_RISK_OF_ACCOUNT: PERCENT_RISK_OF_ACCOUNT_DESCRIPTION,
        PERCENT_OF_ACCOUNT: PERCENT_OF_ACCOUNT_DESCRIPTION,
    }
    DESCRIPTIONS = [
        QUANTITY_RISK_OF_ACCOUNT_DESCRIPTION,
        PERCENT_RISK_OF_ACCOUNT_DESCRIPTION,
        PERCENT_OF_ACCOUNT_DESCRIPTION,
    ]


class ManagedOrderSettingsPositionSize(sl_settings.ManagedOrderSettingsSL):
    def __init__(self) -> None:
        super().__init__()
        self.ctx: context_management.Context = None

        self.position_size_path: str = None
        self.position_size_setting_name: str = None

        self.position_size_type: str = None
        self.risk_in_d: float = None
        self.total_risk_in_d: float = None
        self.risk_in_p: float = None
        self.total_risk_in_p: float = None
        
        self.user_input_name_prefix: str = None

    async def initialize_position_size_settings(self):
        if self.sl_type == sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION:
            position_size_options = [
                ManagedOrderSettingsPositionSizeTypes.PERCENT_OF_ACCOUNT_DESCRIPTION
            ]
            position_size_def_val = (
                ManagedOrderSettingsPositionSizeTypes.PERCENT_OF_ACCOUNT_DESCRIPTION
            )
        else:
            position_size_options = ManagedOrderSettingsPositionSizeTypes.DESCRIPTIONS
            position_size_def_val = (
                ManagedOrderSettingsPositionSizeTypes.PERCENT_RISK_OF_ACCOUNT_DESCRIPTION
            )

        # position size
        self.position_size_type = await basic_keywords.user_input(
            self.ctx,
            "position Size Type",
            "options",
            position_size_def_val,
            options=position_size_options,
            path=self.position_size_path,
            parent_input_name=self.position_size_setting_name,
        )

        # position size based on percent risk
        if (
            self.position_size_type
            == ManagedOrderSettingsPositionSizeTypes.QUANTITY_RISK_OF_ACCOUNT_DESCRIPTION
        ):
            self.risk_in_d = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"risk_per_trade)",
                "float",
                100,
                title="risk per trade (measured in reference market currency)",
                min_val=0,
                path=self.position_size_path,
                parent_input_name=self.position_size_setting_name,
            )
            self.total_risk_in_d = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"total_risk",
                "float",
                200,
                title="total risk (measured in reference market currency)",
                min_val=0,
                path=self.position_size_path,
                parent_input_name=self.position_size_setting_name,
            )

        # position size based on dollar risk (measured in reference market)
        elif (
            self.position_size_type
            == ManagedOrderSettingsPositionSizeTypes.PERCENT_RISK_OF_ACCOUNT_DESCRIPTION
        ):
            self.risk_in_p = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"risk_per_trade_in_%",
                "float",
                0.5,
                title="risk per trade in %",
                min_val=0,
                path=self.position_size_path,
                parent_input_name=self.position_size_setting_name,
            )
            self.total_risk_in_p = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"total_risk_in_%",
                "float",
                2,
                title="total risk in %",
                min_val=0,
                path=self.position_size_path,
                parent_input_name=self.position_size_setting_name,
            )

        # position size based on % of account size
        elif (
            self.position_size_type
            == ManagedOrderSettingsPositionSizeTypes.PERCENT_OF_ACCOUNT_DESCRIPTION
        ):
            self.risk_in_p = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"position_per_trade_in_%_of_account_size",
                "float",
                50,
                title="position per trade in % of account size",
                min_val=0,
                path=self.position_size_path,
                parent_input_name=self.position_size_setting_name,
            )
            self.total_risk_in_p = await basic_keywords.user_input(
                self.ctx,
                self.user_input_name_prefix+"max_position_in_%_of_account_size",
                "float",
                100,
                title="max position in % of account size",
                min_val=0,
                path=self.position_size_path,
                parent_input_name=self.position_size_setting_name,
            )
