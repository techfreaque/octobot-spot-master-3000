# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import octobot_trading.modes.script_keywords.context_management as context_management
import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.tp_settings as tp_settings


class ManagedOrdersSettings(tp_settings.ManagedOrderSettingsTP):
    def __init__(self):
        super().__init__()
        self.ctx: context_management.Context = None

        self.input_root_path: str = None
        self.parent_user_input_name: str = None

        self.entry_path: str = None
        self.entry_setting_name: str = None
        self.exit_path: str = None
        self.exit_setting_name: str = None
        self.sl_path: str = None
        self.trail_sl_path: str = None
        self.sl_setting_name: str = None
        self.sl_trailing_setting_name: str = None
        self.position_size_path: str = None
        self.position_size_setting_name: str = None
        self.tp_path: str = None
        self.tp_setting_name: str = None

        self.initialized: bool = False
        self.managed_order_active: bool = False

        self.enable_alerts: bool = None
        self.recreate_exits: bool = None
        self.adapt_live_exits: bool = None

        self.order_tag_prefix: str = "Managed order"
        self.user_input_name_prefix: str = "managed_order_"

    async def initialize(
        self,
        ctx,
        input_root_path: str,
        parent_user_input_name: str,
        order_tag_prefix: str = "Managed order",
    ):
        self.order_tag_prefix = order_tag_prefix
        await self.initialize_parent_input_or_path(
            ctx, input_root_path, parent_user_input_name
        )
        await self.initialize_entry_settings()
        await self.initialize_sl_settings()
        await self.initialize_position_size_settings()
        await self.initialize_tp_settings()
        await self.initialize_exit_settings()

        # alerts
        self.enable_alerts = await basic_keywords.user_input(
            self.ctx,
            self.user_input_name_prefix + "enable_detailed_trade_alerts",
            "boolean",
            True,
            title="enable detailed trade alerts",
            path=self.input_root_path,
            order=9999,
            parent_input_name=self.parent_user_input_name,
        )

        self.managed_order_active = self.initialized = True

    async def initialize_exit_settings(self):
        pass
        # self.recreate_exits = await basic_keywords.user_input(
        #     self.ctx,
        #     "Recreate exit orders on new entrys: When "
        #     "enabled exit orders will be replaced with "
        #     "new ones based on the current candle",
        #     "boolean",
        #     False,
        #     path=self.exit_path,
        #     parent_input_name=self.exit_setting_name,
        # )
        # self.adapt_live_exits = await basic_keywords.user_input(
        #     self.ctx,
        #     "adapt_live_exits",
        #     "boolean",
        #     False,
        #     title="Adapt live exits based on filled price: When enabled this will place"
        #     " a entry with a stop loss based on candle close. When filled it will edit "
        #     "the stop loss based on filled price and place the take profit afterwards",
        #     path=self.exit_path,
        #     parent_input_name=self.exit_setting_name,
        # )

    async def initialize_parent_input_or_path(
        self, ctx, input_root_path, parent_user_input_name
    ):
        # init parent sections or path
        self.ctx = ctx
        self.input_root_path = input_root_path
        self.parent_user_input_name = parent_user_input_name
        if self.parent_user_input_name:
            self.entry_setting_name = self.user_input_name_prefix + "entry_settings"
            self.exit_setting_name = self.user_input_name_prefix + "exit_settings"
            self.sl_setting_name = self.user_input_name_prefix + "sl_settings"
            self.tp_setting_name = self.user_input_name_prefix + "tp_settings"
            self.sl_trailing_setting_name = (
                self.user_input_name_prefix + "sl_trailing_settings"
            )
            self.position_size_setting_name = (
                self.user_input_name_prefix + "position_size_settings"
            )
            await basic_keywords.user_input(
                self.ctx,
                self.entry_setting_name,
                "object",
                title="Entry settings",
                def_val=None,
                parent_input_name=self.parent_user_input_name,
                other_schema_values={
                    "options": {"collapsed": True},
                    "grid_columns": 12,
                },
            )
            await basic_keywords.user_input(
                self.ctx,
                self.exit_setting_name,
                "object",
                title="Exit settings",
                def_val=None,
                parent_input_name=self.parent_user_input_name,
                other_schema_values={
                    "options": {"collapsed": True},
                    "grid_columns": 12,
                },
            )
            await basic_keywords.user_input(
                self.ctx,
                self.sl_setting_name,
                "object",
                title="Stop loss settings",
                def_val=None,
                parent_input_name=self.exit_setting_name,
                other_schema_values={
                    "options": {"collapsed": True},
                    "grid_columns": 12,
                },
            )
            await basic_keywords.user_input(
                self.ctx,
                self.sl_trailing_setting_name,
                "object",
                title="Trailing stop loss settings",
                def_val=None,
                parent_input_name=self.exit_setting_name,
                other_schema_values={
                    "options": {"collapsed": True},
                    "grid_columns": 12,
                },
            )
            await basic_keywords.user_input(
                self.ctx,
                self.tp_setting_name,
                "object",
                title="Take profit settings",
                def_val=None,
                parent_input_name=self.exit_setting_name,
                other_schema_values={
                    "options": {"collapsed": True},
                    "grid_columns": 12,
                },
            )
            await basic_keywords.user_input(
                self.ctx,
                self.position_size_setting_name,
                "object",
                title="Position size settings",
                def_val=None,
                parent_input_name=self.parent_user_input_name,
                other_schema_values={
                    "options": {"collapsed": True},
                    "grid_columns": 12,
                },
            )
        else:
            self.entry_path = self.input_root_path + "/Entry Settings"
            self.exit_path = self.input_root_path + "/Exit Settings"
            self.sl_path = self.exit_path + "/Stop Loss Settings"
            self.trail_sl_path = self.sl_path + "/Trailing Stop Settings"
            self.tp_path = self.exit_path + "/Take Profit Settings"
            self.position_size_path = self.input_root_path + "/Position Size Settings"
