# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.order_notification as order_notification
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.order_placement as order_placement
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.all_settings as all_settings


async def activate_managed_orders(
    ctx,
    user_input_path: str = "evaluator/Managed_Order_Settings",
    parent_input_name: str = None,
    order_tag_prefix: str = "Managed order",
):
    if parent_input_name:
        user_input_path = None
    try:
        orders_settings = all_settings.ManagedOrdersSettings()
        await orders_settings.initialize(
            ctx, user_input_path, parent_input_name, order_tag_prefix
        )
        return orders_settings
    except Exception as error:
        raise RuntimeError(
            "Managed Order: There is an issue in your Managed Order "
            "configuration. Check the settings: " + str(error)
        ) from error


async def managed_order(
    ctx,
    trading_side="long",
    orders_settings=None,
    user_input_path: str = "evaluator/Managed_Order_Settings",
    sl_indicator_value=None,
    parent_input_name: str = None,
):
    """
    :param ctx:
    :param trading_side:
        can be "long" or short
    :param orders_settings:
        pass custom settings or use activate_managed_orders(ctx)
    :param user_input_path: The root path to render managed order settings
    :param sl_indicator_value: When set to SL based on indicator,
            a sl_indicator_value for the current candle must be provided
    :return:
    """
    if not ctx.enable_trading:
        return
    _managed_order = ManagedOrder()
    return await _managed_order.initialize_and_trade(
        ctx,
        trading_side,
        orders_settings,
        user_input_path,
        parent_input_name,
        sl_indicator_value,
    )


class ManagedOrder(order_placement.ManagedOrderPlacement):
    async def initialize_and_trade(
        self,
        ctx,
        trading_side,
        orders_settings: all_settings.ManagedOrdersSettings,
        user_input_path: str = None,
        parent_input_name: str = None,
        sl_indicator_value: float = None,
    ):
        self.managed_orders_settings = (
            orders_settings or all_settings.ManagedOrdersSettings()
        )
        if not self.managed_orders_settings.initialized:
            await self.managed_orders_settings.initialize(
                ctx, user_input_path, parent_input_name
            )
        self.sl_indicator_value = sl_indicator_value
        self.set_trading_sides(trading_side)

        # # get position size
        # await self.set_managed_position_size(ctx)

        #     # get order tag and position mode
        #     await self.set_managed_amount_and_order_tag(ctx)

        # create entry and exit orders orders if possible
        await self.place_managed_entry_and_exits(ctx)
        if self.place_entries:

            # send an alert in live mode
            await order_notification.send_managed_order_notification(ctx, self)
        return self
