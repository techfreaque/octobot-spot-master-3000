# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import octobot_trading.enums as trading_enums
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.all_settings as all_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings as sl_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.tp_settings as tp_settings
import tentacles.Meta.Keywords.scripting_library.orders.cancelling as cancelling
import random as random
import tentacles.Meta.Keywords.scripting_library.orders.grouping as grouping


class ManagedOrderUtilities:
    def __init__(self):
        self.trading_side = ""
        self.entry_side = ""
        self.exit_side = ""
        self.exit_target_position = 0
        self.exit_amount = 0
        self.exit_order_tag = ""
        self.entry_order_tag = ""
        self.order_group = None
        self.enabled_order_group = False
        self.created_orders = None
        self.managed_orders_settings: all_settings.ManagedOrdersSettings = None
        self.position_size_market = 0

    def set_trading_sides(self, trading_side):
        self.trading_side = trading_side
        if self.trading_side == trading_enums.PositionSide.LONG.value:
            self.trading_side = self.trading_side
            self.entry_side = trading_enums.TradeOrderSide.BUY.value
            self.exit_side = trading_enums.TradeOrderSide.SELL.value

        elif self.trading_side == trading_enums.PositionSide.SHORT.value:
            self.entry_side = trading_enums.TradeOrderSide.SELL.value
            self.exit_side = trading_enums.TradeOrderSide.BUY.value
        else:
            raise RuntimeError('managed order: trading side must be "short" or "long"')

    def set_managed_order_tags(self):
        if self.managed_orders_settings.recreate_exits:
            self.exit_order_tag = (
                f"{self.managed_orders_settings.order_tag_prefix} "
                f"{self.trading_side} exit:"
            )
            self.entry_order_tag = (
                f"{self.managed_orders_settings.order_tag_prefix} "
                f"{self.trading_side} entry:"
            )
        else:
            order_tag_id = random.randint(0, 999999999)
            self.exit_order_tag = (
                f"{self.managed_orders_settings.order_tag_prefix} "
                f"{self.trading_side} exit (id: {order_tag_id})"
            )
            self.entry_order_tag = (
                f"{self.managed_orders_settings.order_tag_prefix} {self.trading_side} "
                f"entry (id: {order_tag_id})"
            )

    async def handle_order_recreate_mode(self, ctx):
        if self.managed_orders_settings.recreate_exits:
            # todo use edit orders instead
            await cancelling.cancel_orders(ctx, self.exit_order_tag)

    # async def set_managed_amount_and_order_tag(self, ctx):
    #     # either replace existing exits or keep them and add new exits for new entry
    #     self.exit_amount = None
    #     self.exit_target_position = None
    #     if self.managed_orders_settings.recreate_exits:
    #         self.exit_target_position = 0
    #         self.exit_order_tag = f"managed_order {self.trading_side} exit:"
    #         self.entry_order_tag = f"managed_order {self.trading_side} entry:"
    #         # todo use edit orders instead
    #         await cancelling.cancel_orders(ctx, self.exit_order_tag)
    #         await cancelling.cancel_orders(ctx, self.entry_order_tag)
    #     else:  # keep existing exit orders and only add new exits
    #         self.exit_amount = self.position_size
    #         # todo use something unique to avoid canceling eventual other orders in the same candle
    #         order_tag_id = random.randint(0, 999999999)
    #         self.exit_order_tag = (
    #             f"managed_order {self.trading_side} exit (id: {order_tag_id})"
    #         )
    #         self.entry_order_tag = (
    #             f"managed_order {self.trading_side} entry (id: {order_tag_id})"
    #         )

    async def handle_manged_order_group(self, ctx):
        # order grouping
        self.order_group = None
        self.enabled_order_group = False
        if (
            tp_settings.ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION
            != self.managed_orders_settings.tp_type
            and sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
            != self.managed_orders_settings.sl_type
        ):
            try:
                self.order_group = (
                    grouping.get_or_create_balanced_take_profit_and_stop_group(
                        ctx, orders=self.created_orders
                    )
                )
            except AttributeError:
                # try to continue creating exits without grouping as entries are probably placed already
                self.enabled_order_group = False
                ctx.logger.error(
                    "Managed order: failed to activate exit order grouping"
                )
                return self
            # disable group to be able to create stop and take profit orders sequentially
            await grouping.enable_group(self.order_group, False)
            self.enabled_order_group = True
