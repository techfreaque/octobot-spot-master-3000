# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import octobot_trading.modes.script_keywords.context_management as context_management
from tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.data.public_exchange_data import (
    get_candles_,
)


class BasicMaker:
    def __init__(self, ctx):
        self.ctx = ctx


async def activate_standalone_data_source(
    title,
    parent_input_name: str = None,
    indicator_id: int = 1,
    maker=None,
):
    indicator_id += 200

    data_source_values = await _get_standalone_data_source(
        maker, title, parent_input_name, indicator_id
    )
    times = await get_candles_(maker, "time")
    data_source_dict = {}
    for index in range(0, len(data_source_values)):
        data_source_dict[times[-index - 1]] = data_source_values[-index - 1]

    maker.consumable_indicator_cache[
        get_cache_path(maker, indicator_id)
    ] = data_source_dict
    return maker


def get_standalone_data_source(indicator_id, maker):
    indicator_id += 200
    try:
        return maker.consumable_indicator_cache[get_cache_path(maker, indicator_id)][
            maker.ctx.trigger_cache_timestamp
        ]
    except KeyError:
        maker.ctx.logger.error(
            f"Data source {indicator_id} doesnt have a value for the "
            f"current candle. Check the candle history size"
        )
        return False


async def _get_standalone_data_source(
    maker,
    title,
    parent_input_name: str = None,
    indicator_id: int = 1,
):
    from tentacles.Meta.Keywords.matrix_library.matrix_strategy_maker_keywords.evaluators.evaluators_handling import (
        Evaluator_,
    )

    sl_evaluator = Evaluator_(maker, input_path_short_root=parent_input_name, input_name_root=parent_input_name)
    await sl_evaluator.init_evaluator(maker, maker.ctx, indicator_id)
    indicator = maker.INDICATOR_CLASS()
    await indicator.init_indicator(
        maker,
        sl_evaluator,
        data_source_name=title,
        def_val="EMA",
        enable_oscillators=True,
        enable_price_indicators=True,
        enable_price_data=True,
        enable_volume=True,
        enable_static_value=True,
        enable_force_def_val=False,
    )
    maker.indicators[indicator.cache_path] = sl_evaluator.indicators[
        indicator_id
    ] = indicator
    data_source_values, _, _ = await indicator.get_indicator_data(
        maker,
        evaluator=sl_evaluator,
    )
    return data_source_values


def get_cache_path(maker, indicator_id):
    return (
        f"b-{indicator_id}"
        if maker.ctx.exchange_manager.is_backtesting
        else f"l-{indicator_id}"
    )
