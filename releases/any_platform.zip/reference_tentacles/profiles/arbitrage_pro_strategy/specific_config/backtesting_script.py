async def script(run_data):
    import tentacles.Meta.Keywords.matrix_library.RunAnalysis.AnalysisMode.default_run_analysis_mode.run_analysis_mode as run_analysis_mode

    # import tentacles.Meta.Keywords.matrix_library.RunAnalysis.BaseDataProvider.default_base_data_provider.base_data_provider as base_data_provider

    return await run_analysis_mode.DefaultRunAnalysisMode().run_analysis_script(
        run_data
    )
